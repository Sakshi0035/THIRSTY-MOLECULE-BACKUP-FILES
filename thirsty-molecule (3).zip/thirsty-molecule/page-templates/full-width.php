<?php
/**
 * Template Name: Full Width (Elementor / Page Builder)
 * Template Post Type: page, post
 *
 * A blank canvas that keeps the theme header and footer but removes all
 * content constraints so Elementor sections can stretch edge to edge.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="tm-fullwidth-content">
	<?php
	while ( have_posts() ) {
		the_post();
		the_content();

		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	}
	?>
</div>

<?php
get_footer();

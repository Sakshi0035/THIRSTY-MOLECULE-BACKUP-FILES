<?php
/**
 * Single page template.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="site-main-inner no-sidebar">
	<div>
		<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', 'single' );

			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		}
		?>
	</div>
</div>

<?php
get_footer();

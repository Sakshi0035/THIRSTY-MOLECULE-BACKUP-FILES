<?php
/**
 * Main template: blog index and universal fallback.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<header class="page-header">
	<h1 class="page-title">
		<?php
		if ( is_home() && ! is_front_page() ) {
			echo esc_html( get_the_title( (int) get_option( 'page_for_posts' ) ) );
		} else {
			esc_html_e( 'Journal', 'thirsty-molecule' );
		}
		?>
	</h1>
</header>

<div class="site-main-inner<?php echo is_active_sidebar( 'sidebar-1' ) ? '' : ' no-sidebar'; ?>">
	<div>
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/content' );
			}
			thirsty_molecule_pagination();
		} else {
			get_template_part( 'template-parts/content', 'none' );
		}
		?>
	</div>
	<?php get_sidebar(); ?>
</div>

<?php
get_footer();

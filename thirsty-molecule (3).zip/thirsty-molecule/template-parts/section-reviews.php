<?php
/**
 * Review cards.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="reviews">
	<p class="section-kicker"><?php esc_html_e( 'REVIEW LAYOUT PREVIEW', 'thirsty-molecule' ); ?></p>
	<h2><?php echo esc_html( thirsty_molecule_mod( 'tm_reviews_heading', __( 'Skin has opinions.', 'thirsty-molecule' ) ) ); ?></h2>
	<p class="review-intro"><?php echo esc_html( thirsty_molecule_mod( 'tm_reviews_intro', __( 'Fortunately, some of them are very flattering.', 'thirsty-molecule' ) ) ); ?></p>
	<div class="review-row">
		<?php foreach ( thirsty_molecule_reviews() as $tm_review ) : ?>
			<article>
				<span aria-label="<?php esc_attr_e( '5 out of 5 stars', 'thirsty-molecule' ); ?>">★★★★★</span>
				<h3><?php echo esc_html( $tm_review['title'] ); ?></h3>
				<p><?php echo esc_html( $tm_review['text'] ); ?></p>
				<b><?php echo esc_html( $tm_review['author'] ); ?></b>
			</article>
		<?php endforeach; ?>
	</div>
</section>

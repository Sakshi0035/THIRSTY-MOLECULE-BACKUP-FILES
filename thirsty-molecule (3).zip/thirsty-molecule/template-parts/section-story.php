<?php
/**
 * Founder story.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<section id="story" class="story section-white">
	<div>
		<p class="section-kicker"><?php esc_html_e( 'HOW IT ALL STARTED', 'thirsty-molecule' ); ?></p>
		<h2><?php echo esc_html( thirsty_molecule_mod( 'tm_story_heading', __( 'Formula, not folklore.', 'thirsty-molecule' ) ) ); ?></h2>
		<p><?php echo esc_html( thirsty_molecule_mod( 'tm_story_text1', __( 'Tara Prabhu is a chemical engineer and certified skincare formulator who spent more than 17 years in corporate HR before skincare sent her career in a very different direction. It began with postpartum hair loss—and a determination to understand what actually goes into the products we trust.', 'thirsty-molecule' ) ) ); ?></p>
		<p><?php echo esc_html( thirsty_molecule_mod( 'tm_story_text2', __( 'That curiosity became formal training: two certifications in Ayurvedic cosmetology, followed by professional diplomas in organic skincare and haircare formulation from Formula Botanica. Today, Tara works closely with the manufacturer’s R&D team to turn formulation science into skincare that feels cheerful, uncomplicated and very sure of what it is doing.', 'thirsty-molecule' ) ) ); ?></p>
		<strong><?php echo esc_html( thirsty_molecule_mod( 'tm_story_note', __( '— No decorative actives. No miracle timelines.', 'thirsty-molecule' ) ) ); ?></strong>
	</div>
	<aside>
		<span><?php esc_html_e( 'THE MOLECULE BEHIND THE OBSESSION', 'thirsty-molecule' ); ?></span>
		<b><?php esc_html_e( 'H₂O', 'thirsty-molecule' ); ?></b>
		<span><?php esc_html_e( 'Basic chemistry. Very good skin manners.', 'thirsty-molecule' ); ?></span>
	</aside>
</section>

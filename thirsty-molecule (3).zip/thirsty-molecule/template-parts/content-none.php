<?php
/**
 * Empty results message.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="entry">
	<h2 class="entry-title"><?php esc_html_e( 'Nothing found here.', 'thirsty-molecule' ); ?></h2>
	<div class="entry-content">
		<p><?php esc_html_e( 'Try another search — hydration-related terms usually work best.', 'thirsty-molecule' ); ?></p>
		<?php get_search_form(); ?>
	</div>
</div>

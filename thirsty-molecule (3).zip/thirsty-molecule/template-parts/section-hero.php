<?php
/**
 * Hero carousel.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

$tm_slides = thirsty_molecule_slides();

if ( empty( $tm_slides ) ) {
	return;
}

$tm_first = $tm_slides[0];
?>
<section id="top" class="hero <?php echo esc_attr( $tm_first['id'] ); ?>" data-tm-carousel data-slides="<?php echo esc_attr( wp_json_encode( $tm_slides ) ); ?>" aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured products', 'thirsty-molecule' ); ?>">
	<div class="hero-copy">
		<p class="eyebrow"><?php echo esc_html( $tm_first['ritual'] ); ?></p>
		<h1><?php echo esc_html( $tm_first['title'] ); ?></h1>
		<p class="hero-text"><?php echo esc_html( wp_strip_all_tags( $tm_first['text'] ) ); ?></p>
		<div class="hero-actions">
			<a href="<?php echo esc_url( $tm_first['primary_url'] ); ?>"><?php echo esc_html( $tm_first['primary'] ); ?></a>
			<?php if ( ! empty( $tm_first['secondary'] ) ) : ?>
				<a href="<?php echo esc_url( $tm_first['secondary_url'] ); ?>"><?php echo esc_html( $tm_first['secondary'] ); ?></a>
			<?php endif; ?>
		</div>
	</div>

	<div class="hero-product"<?php echo $tm_first['show_product'] ? '' : ' hidden style="display:none"'; ?>>
		<img src="<?php echo esc_url( $tm_first['image'] ); ?>" alt="<?php echo esc_attr( sprintf( /* translators: %s: product name. */ __( '%s product', 'thirsty-molecule' ), $tm_first['id'] ) ); ?>" width="860" height="860" fetchpriority="high" decoding="async" />
	</div>

	<button class="arrow prev" type="button" aria-label="<?php esc_attr_e( 'Previous product', 'thirsty-molecule' ); ?>">&lsaquo;</button>
	<button class="arrow next" type="button" aria-label="<?php esc_attr_e( 'Next product', 'thirsty-molecule' ); ?>">&rsaquo;</button>

	<div class="dots">
		<?php foreach ( $tm_slides as $tm_index => $tm_slide ) : ?>
			<button type="button" class="<?php echo 0 === $tm_index ? 'active' : ''; ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name. */ __( 'View %s', 'thirsty-molecule' ), $tm_slide['id'] ) ); ?>"></button>
		<?php endforeach; ?>
	</div>
</section>

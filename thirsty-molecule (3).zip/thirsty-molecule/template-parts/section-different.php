<?php
/**
 * "What makes us different" dark panel.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="different">
	<div>
		<p class="section-kicker"><?php echo esc_html( thirsty_molecule_mod( 'tm_different_kicker', __( 'WHAT MAKES US DIFFERENT', 'thirsty-molecule' ) ) ); ?></p>
		<h2><?php echo esc_html( thirsty_molecule_mod( 'tm_different_heading', __( 'Formula, not folklore.', 'thirsty-molecule' ) ) ); ?></h2>
		<p><?php echo esc_html( thirsty_molecule_mod( 'tm_different_text1', __( 'We don’t believe every bottle needs half the periodic table. Sometimes, the right ingredients at the right concentrations—and a pH that behaves itself—are exactly what the skin ordered.', 'thirsty-molecule' ) ) ); ?></p>
		<p><?php echo esc_html( thirsty_molecule_mod( 'tm_different_text2', __( 'Every product is built to do its job, not simply look impressive on a label. No miracle claims, because every skin is different. No decorative actives either. Just cheerful skincare that knows what it’s doing.', 'thirsty-molecule' ) ) ); ?></p>
	</div>
</section>

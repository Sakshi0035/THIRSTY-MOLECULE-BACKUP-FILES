<?php
/**
 * Values / why us.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<section id="why" class="why">
	<h2><?php echo esc_html( thirsty_molecule_mod( 'tm_why_heading', __( 'What we won’t compromise on.', 'thirsty-molecule' ) ) ); ?></h2>
	<div class="why-grid">
		<?php foreach ( thirsty_molecule_values() as $tm_value ) : ?>
			<article>
				<b><?php echo esc_html( $tm_value['number'] ); ?></b>
				<h3><?php echo esc_html( $tm_value['title'] ); ?></h3>
				<p><?php echo esc_html( $tm_value['text'] ); ?></p>
			</article>
		<?php endforeach; ?>
	</div>
</section>

<?php
/**
 * Trust badges strip.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="trust-strip" aria-label="<?php esc_attr_e( 'Product standards', 'thirsty-molecule' ); ?>">
	<?php foreach ( thirsty_molecule_trust() as $tm_item ) : ?>
		<article>
			<span class="trust-icon <?php echo esc_attr( $tm_item['class'] ); ?>" aria-hidden="true"><?php echo esc_html( $tm_item['icon'] ); ?></span>
			<b><?php echo esc_html( $tm_item['title'] ); ?></b>
			<p><?php echo esc_html( $tm_item['text'] ); ?></p>
		</article>
	<?php endforeach; ?>
</section>

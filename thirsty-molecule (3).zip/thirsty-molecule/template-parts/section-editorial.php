<?php
/**
 * Editorial model banner.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

$tm_image = thirsty_molecule_mod( 'tm_editorial_image', thirsty_molecule_image( 'hydramatrix-editorial-model-funky.jpg' ) );
?>
<section class="model-editorial">
	<img src="<?php echo esc_url( $tm_image ); ?>" alt="<?php echo esc_attr( thirsty_molecule_mod( 'tm_editorial_alt', __( 'Joyful woman holding HydraMatrix moisturizer', 'thirsty-molecule' ) ) ); ?>" width="1200" height="1500" loading="lazy" decoding="async" />
	<div>
		<p class="section-kicker"><?php echo esc_html( thirsty_molecule_mod( 'tm_editorial_kicker', __( 'HYDRATION, CAUGHT SMILING', 'thirsty-molecule' ) ) ); ?></p>
		<h2><?php echo esc_html( thirsty_molecule_mod( 'tm_editorial_heading', __( 'Hydration looks good on you.', 'thirsty-molecule' ) ) ); ?></h2>
		<p><?php echo esc_html( thirsty_molecule_mod( 'tm_editorial_text', __( 'Plump-looking skin. Dewy finish. Grease left on read.', 'thirsty-molecule' ) ) ); ?></p>
		<a href="<?php echo esc_url( thirsty_molecule_mod( 'tm_editorial_url', '#range' ) ); ?>"><?php echo esc_html( thirsty_molecule_mod( 'tm_editorial_cta', __( 'Shop HydraMatrix', 'thirsty-molecule' ) ) ); ?></a>
	</div>
</section>

<?php
/**
 * Full post/page content.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
	<h1 class="entry-title"><?php the_title(); ?></h1>

	<?php if ( 'post' === get_post_type() ) : ?>
		<?php thirsty_molecule_entry_meta(); ?>
	<?php endif; ?>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="entry-thumb"><?php the_post_thumbnail( 'large' ); ?></div>
	<?php endif; ?>

	<div class="entry-content">
		<?php
		the_content();
		wp_link_pages(
			array(
				'before' => '<div class="tm-pagination">',
				'after'  => '</div>',
			)
		);
		?>
	</div>
</article>

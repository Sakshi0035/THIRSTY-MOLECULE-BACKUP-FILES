<?php
/**
 * Newsletter signup band.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

$tm_action = thirsty_molecule_mod( 'tm_signup_action', '' );
?>
<section class="signup">
	<p class="section-kicker"><?php echo esc_html( thirsty_molecule_mod( 'tm_signup_kicker', __( 'THE LAB LIST', 'thirsty-molecule' ) ) ); ?></p>
	<h2><?php echo esc_html( thirsty_molecule_mod( 'tm_signup_heading', __( 'Know when the next molecule drops.', 'thirsty-molecule' ) ) ); ?></h2>
	<p><?php echo esc_html( thirsty_molecule_mod( 'tm_signup_text', __( 'Launch notes, useful skin talk and the occasional formula obsession. No inbox flooding.', 'thirsty-molecule' ) ) ); ?></p>
	<form<?php echo $tm_action ? ' action="' . esc_url( $tm_action ) . '" method="post"' : ''; ?>>
		<label class="screen-reader-text" for="tm-signup-email"><?php esc_html_e( 'Email address', 'thirsty-molecule' ); ?></label>
		<input id="tm-signup-email" type="email" name="email" placeholder="you@email.com" autocomplete="email" />
		<button type="<?php echo $tm_action ? 'submit' : 'button'; ?>"><?php echo esc_html( thirsty_molecule_mod( 'tm_signup_button', __( 'Keep me posted', 'thirsty-molecule' ) ) ); ?></button>
	</form>
	<p class="signup-disclaimer"><?php echo esc_html( thirsty_molecule_mod( 'tm_signup_disclaimer', __( '*By providing your email address you are agreeing to receive email communications from Thirsty Molecule, its affiliates, brands and/or marketing partners. This can be changed at any time. Please refer to our Privacy Policy and Terms of Use for more details, or Contact Us.', 'thirsty-molecule' ) ) ); ?></p>
</section>

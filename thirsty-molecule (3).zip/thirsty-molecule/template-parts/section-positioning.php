<?php
/**
 * Brand positioning statement.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

$tm_kicker = get_theme_mod( 'tm_positioning_kicker', '' );
?>
<section class="positioning section-white">
	<div class="positioning-copy">
		<?php if ( $tm_kicker ) : ?>
			<p class="section-kicker"><?php echo esc_html( $tm_kicker ); ?></p>
		<?php endif; ?>
		<h2>
			<?php esc_html_e( 'Skin has many ambitions: ', 'thirsty-molecule' ); ?><span><?php esc_html_e( 'glow, brightness, calm, graceful ageing.', 'thirsty-molecule' ); ?></span> <?php esc_html_e( 'But first, it needs water—and a barrier that knows how to hold on to it.', 'thirsty-molecule' ); ?>
		</h2>
		<p><?php echo esc_html( thirsty_molecule_mod( 'tm_positioning_text', __( 'At Thirsty Molecule, every formula begins with one question: will this genuinely hydrate and support the skin barrier, or is it simply fluent in marketing? Cleansers, moisturisers, serums and whatever is currently bubbling in the lab—different jobs, same starting point.', 'thirsty-molecule' ) ) ); ?></p>
		<p><strong><?php echo esc_html( thirsty_molecule_mod( 'tm_positioning_note', __( 'Hydration first. Everything good follows.', 'thirsty-molecule' ) ) ); ?></strong></p>
	</div>
</section>

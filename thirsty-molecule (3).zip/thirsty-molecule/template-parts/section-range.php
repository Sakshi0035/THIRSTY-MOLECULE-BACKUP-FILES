<?php
/**
 * Product range grid.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<section id="range" class="range section-white">
	<div class="section-head">
		<h2><?php echo esc_html( thirsty_molecule_mod( 'tm_range_heading', __( 'Our Range.', 'thirsty-molecule' ) ) ); ?></h2>
	</div>

	<div class="range-grid">
		<?php foreach ( thirsty_molecule_range() as $tm_index => $tm_card ) : ?>
			<article class="range-<?php echo esc_attr( $tm_index ); ?>">
				<?php if ( ! empty( $tm_card['tag'] ) ) : ?>
					<span class="tag"><?php echo esc_html( $tm_card['tag'] ); ?></span>
				<?php endif; ?>
				<div class="range-image">
					<img src="<?php echo esc_url( $tm_card['image'] ); ?>" alt="<?php echo esc_attr( $tm_card['name'] ); ?>" width="800" height="615" loading="lazy" decoding="async" />
				</div>
				<h3><?php echo esc_html( $tm_card['name'] ); ?></h3>
				<?php if ( ! empty( $tm_card['sub'] ) ) : ?>
					<p class="range-sub"><?php echo esc_html( $tm_card['sub'] ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $tm_card['text'] ) ) : ?>
					<p><?php echo esc_html( $tm_card['text'] ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $tm_card['chip1'] ) || ! empty( $tm_card['chip2'] ) ) : ?>
					<div class="chips">
						<?php if ( ! empty( $tm_card['chip1'] ) ) : ?>
							<span><?php echo esc_html( $tm_card['chip1'] ); ?></span>
						<?php endif; ?>
						<?php if ( ! empty( $tm_card['chip2'] ) ) : ?>
							<span><?php echo esc_html( $tm_card['chip2'] ); ?></span>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<footer>
					<?php if ( ! empty( $tm_card['price'] ) ) : ?>
						<b><?php echo esc_html( $tm_card['price'] ); ?></b>
					<?php endif; ?>
					<a class="range-button" href="<?php echo esc_url( $tm_card['url'] ); ?>"><?php echo esc_html( $tm_card['button'] ); ?></a>
				</footer>
			</article>
		<?php endforeach; ?>
	</div>

	<a class="view-all" href="<?php echo esc_url( thirsty_molecule_mod( 'tm_range_all_url', '#range' ) ); ?>">
		<?php echo esc_html( thirsty_molecule_mod( 'tm_range_all_label', __( 'View all products', 'thirsty-molecule' ) ) ); ?> <span>&#8599;</span>
	</a>
</section>

<?php
/**
 * Scrolling ticker / announcement bar.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

$tm_phrases = array(
	thirsty_molecule_mod( 'tm_ticker_1', 'THE LAB IS OPEN ✦ WELCOME TO THIRSTY MOLECULE' ),
	thirsty_molecule_mod( 'tm_ticker_2', 'CETAGLOW + HYDRAMATRIX ARE OFFICIALLY LIVE' ),
	thirsty_molecule_mod( 'tm_ticker_3', 'TWO NEW FORMULAS ✦ CURRENTLY BUBBLING' ),
);

/* The list is duplicated so the CSS marquee loops seamlessly. */
$tm_loop = array_merge( $tm_phrases, array( $tm_phrases[0], $tm_phrases[1] ) );
?>
<div class="ticker" aria-hidden="true">
	<div>
		<?php foreach ( $tm_loop as $tm_index => $tm_phrase ) : ?>
			<span><?php echo esc_html( $tm_phrase ); ?></span>
			<?php if ( $tm_index < count( $tm_loop ) - 1 ) : ?>
				<b>&#10022;</b>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
</div>

<?php
/**
 * Post summary used in archives and the blog index.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="entry-thumb" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
			<?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?>
		</a>
	<?php endif; ?>

	<h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
	<?php thirsty_molecule_entry_meta(); ?>

	<div class="entry-content"><?php the_excerpt(); ?></div>

	<a class="btn-pill" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'thirsty-molecule' ); ?></a>
</article>

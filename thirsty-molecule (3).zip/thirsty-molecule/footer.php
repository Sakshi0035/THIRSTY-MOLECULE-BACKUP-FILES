<?php
/**
 * Site footer.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

$tm_email     = thirsty_molecule_mod( 'tm_footer_email', 'hello@thirstymolecule.com' );
$tm_email     = 'hello@thirstymolecule.com';

$tm_phone     = thirsty_molecule_mod( 'tm_footer_phone', '' );
$tm_address   = thirsty_molecule_mod( 'tm_footer_address', '' );

$tm_instagram = thirsty_molecule_mod( 'tm_social_instagram', 'https://instagram.com/thirstymolecule' );

$tm_linkedin  = thirsty_molecule_mod( 'tm_social_linkedin', 'https://www.linkedin.com/company/thirstymolecule/' );
$tm_linkedin  = 'https://www.linkedin.com/company/thirstymolecule/';

$tm_facebook  = thirsty_molecule_mod( 'tm_social_facebook', 'https://www.facebook.com/profile.php?id=61591780889542' );
$tm_facebook  = 'https://www.facebook.com/profile.php?id=61591780889542';

$tm_youtube   = thirsty_molecule_mod( 'tm_social_youtube', '#' );
$tm_x         = thirsty_molecule_mod( 'tm_social_x', '#' );

/*
 * THIRSTY MOLECULE WHATSAPP BUSINESS NUMBER
 */
$tm_whatsapp_number = '9137841175';
$tm_whatsapp_display = '+91 91378 41175';

$tm_copy      = thirsty_molecule_mod(
	'tm_footer_copyright',
	sprintf(
		__( '© %1$s %2$s. All rights reserved.', 'thirsty-molecule' ),
		gmdate( 'Y' ),
		get_bloginfo( 'name', 'display' )
	)
);
?>
</main>

<style>
	footer.footer {
		font-size: 16px !important;
		line-height: 1.6 !important;
	}

	footer.footer .footer-logo {
		font-size: 22px !important;
		font-weight: 700 !important;
	}

	footer.footer p,
	footer.footer a,
	footer.footer span {
		font-size: 15px !important;
	}

	footer.footer b {
		font-size: 16px !important;
		letter-spacing: 0.5px;
		margin-bottom: 8px;
		display: inline-block;
	}

	footer.footer small,
	footer.footer em {
		font-size: 14px !important;
	}

	footer.footer .footer-social-icons svg {
		width: 24px !important;
		height: 24px !important;
	}


	/* =========================================================
	   DESKTOP WHATSAPP
	   Icon + number below email
	   NON-CLICKABLE
	   ========================================================= */

	.tm-whatsapp-desktop {
		display: flex;
		align-items: center;
		gap: 8px;
		margin-top: 8px;
	}

	.tm-whatsapp-desktop-icon {
		width: 24px;
		height: 24px;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
	}

	.tm-whatsapp-desktop-icon svg {
		width: 24px !important;
		height: 24px !important;
	}

	.tm-whatsapp-desktop-number {
		font-size: 15px !important;
		color: inherit !important;
		text-decoration: none !important;
		cursor: default !important;
	}


	/* =========================================================
	   MOBILE WHATSAPP
	   Icon only inside FOLLOW social icons
	   ========================================================= */

	.tm-whatsapp-mobile {
		display: none;
		align-items: center;
		justify-content: center;
		text-decoration: none !important;
	}

	.tm-whatsapp-mobile svg {
		width: 24px !important;
		height: 24px !important;
		display: block;
	}


	@media screen and (max-width: 767px) {

		footer.footer {
			display: grid !important;
			grid-template-columns: 1fr 1fr !important;
			gap: 16px 12px !important;
		}

		footer.footer > div:nth-child(1) {
			grid-column: span 2 !important;
		}

		footer.footer > div:nth-child(3) {
			grid-column: 2 !important;
			grid-row: 2 !important;
		}

		footer.footer > div:nth-child(5) {
			grid-column: 2 !important;
			grid-row: 3 !important;
			margin-top: -6px !important;
		}

		footer.footer > div:nth-child(4) {
			grid-column: 1 !important;
			grid-row: 3 !important;
		}

		footer.footer small,
		footer.footer em {
			grid-column: span 2 !important;
		}

		footer.footer .footer-social-icons {
			gap: 10px !important;
			margin-top: 4px !important;
		}

		footer.footer .footer-social-icons svg {
			width: 18px !important;
			height: 18px !important;
		}


		/* MOBILE:
		   Hide desktop WhatsApp number completely */
		.tm-whatsapp-desktop {
			display: none !important;
		}


		/* MOBILE:
		   Show WhatsApp icon beside Instagram/Facebook/LinkedIn/YouTube/X */
		.tm-whatsapp-mobile {
			display: inline-flex !important;
		}

		.tm-whatsapp-mobile svg {
			width: 18px !important;
			height: 18px !important;
		}
	}
</style>

<footer class="footer">

	<div>
		<a class="footer-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php echo esc_html( strtoupper( get_bloginfo( 'name', 'display' ) ) ); ?>
		</a>

		<p>
			<?php echo esc_html( thirsty_molecule_mod( 'tm_footer_tagline', __( 'Hydration first. Everything good follows.', 'thirsty-molecule' ) ) ); ?>
		</p>

		<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
			<?php dynamic_sidebar( 'footer-1' ); ?>
		<?php endif; ?>
	</div>


	<div class="footer-col-links">

		<b><?php esc_html_e( 'INFO', 'thirsty-molecule' ); ?></b>

		<?php
		thirsty_molecule_footer_links(
			'footer-info',
			array(
				__( 'About us', 'thirsty-molecule' ) => home_url( '/#about-us' ),
				__( 'FAQs', 'thirsty-molecule' )     => home_url( '/faqs/' ),
				__( 'Blog', 'thirsty-molecule' )     => home_url( '/blog/' ),
			)
		);
		?>

	</div>


	<div class="footer-col-links" id="tm-footer-help">

		<b><?php esc_html_e( 'HELP', 'thirsty-molecule' ); ?></b>

		<p style="margin: 0; padding: 0;">
			<?php esc_html_e( 'Contact us:', 'thirsty-molecule' ); ?>
		</p>

		<?php if ( $tm_email ) : ?>

			<a href="<?php echo esc_url( 'mailto:' . antispambot( $tm_email ) ); ?>">
				<?php echo esc_html( antispambot( $tm_email ) ); ?>
			</a>

		<?php endif; ?>


		<!-- =====================================================
		     DESKTOP WHATSAPP
		     Appears directly below email.
		     NOT CLICKABLE.
		     ===================================================== -->

		<div class="tm-whatsapp-desktop">

			<span class="tm-whatsapp-desktop-icon" aria-hidden="true">

				<svg viewBox="0 0 24 24">
					<circle cx="12" cy="12" r="12" fill="#25D366"/>
					<path fill="#FFFFFF" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.198-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.372-.025-.521-.075-.149-.669-1.611-.916-2.206-.242-.579-.487-.5-.67-.51-.198-.008-.372-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
					<path fill="#FFFFFF" d="M12.004 2.003a9.97 9.97 0 0 0-8.52 15.15L2.5 21.5l4.45-1.166A9.97 9.97 0 1 0 12.004 2.003zm0 18.13a8.14 8.14 0 0 1-4.15-1.137l-.298-.177-2.641.692.705-2.575-.194-.315a8.13 8.13 0 1 1 6.578 3.512z"/>
				</svg>

			</span>

			<span class="tm-whatsapp-desktop-number">
				<?php echo esc_html( $tm_whatsapp_display ); ?>
			</span>

		</div>


		<?php if ( $tm_phone ) : ?>

			<a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $tm_phone ) ); ?>">
				<?php echo esc_html( $tm_phone ); ?>
			</a>

		<?php endif; ?>


		<?php if ( $tm_address ) : ?>

			<p><?php echo esc_html( $tm_address ); ?></p>

		<?php endif; ?>

	</div>


	<div class="footer-col-links">

		<b><?php esc_html_e( 'OUR COMMITMENTS', 'thirsty-molecule' ); ?></b>

		<?php
		thirsty_molecule_footer_links(
			'footer-commitments',
			array(
				__( 'Privacy Policy', 'thirsty-molecule' ) => home_url( '/privacy-policy/' ),
				__( 'Terms & Conditions', 'thirsty-molecule' ) => home_url( '/terms-conditions/' ),
				__( 'Shipping, Cancellation & Replacemnet Policy', 'thirsty-molecule' ) => home_url( '/shipping-cancellation-and-replacement-policy/' ),
			)
		);
		?>

	</div>


	<div class="footer-col-links">

		<b><?php esc_html_e( 'FOLLOW', 'thirsty-molecule' ); ?></b>

		<div class="footer-social-icons" style="display: flex; gap: 16px; align-items: center; margin-top: 10px;">


			<?php if ( $tm_instagram ) : ?>

				<a href="<?php echo esc_url( $tm_instagram ); ?>" aria-label="Instagram" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; justify-content: center;">

					<svg width="24" height="24" viewBox="0 0 24 24">

						<defs>
							<linearGradient id="ig-official-grad" x1="0%" y1="100%" x2="100%" y2="0%">
								<stop offset="0%" stop-color="#FFD600"/>
								<stop offset="25%" stop-color="#FF7A00"/>
								<stop offset="50%" stop-color="#FF0069"/>
								<stop offset="75%" stop-color="#D300C5"/>
								<stop offset="100%" stop-color="#405DE6"/>
							</linearGradient>
						</defs>

						<rect width="24" height="24" rx="6.5" fill="url(#ig-official-grad)"/>
						<rect x="4.5" y="4.5" width="15" height="15" rx="4" fill="none" stroke="#FFFFFF" stroke-width="1.8"/>
						<circle cx="12" cy="12" r="3.5" fill="none" stroke="#FFFFFF" stroke-width="1.8"/>
						<circle cx="16.2" cy="7.8" r="1.1" fill="#FFFFFF"/>

					</svg>

				</a>

			<?php endif; ?>


			<?php if ( $tm_facebook ) : ?>

				<a href="<?php echo esc_url( $tm_facebook ); ?>" aria-label="Facebook" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; justify-content: center;">

					<svg width="24" height="24" viewBox="0 0 24 24">

						<circle cx="12" cy="12" r="12" fill="#1877F2"/>
						<path fill="#FFFFFF" d="M15.12 12.7l.43-2.8H12.86V8.08c0-.77.38-1.52 1.58-1.52h1.23V4.18s-1.11-.19-2.18-.19c-2.22 0-3.67 1.35-3.67 3.78v2.13H7.36v2.8h2.46V19.5a12.08 12.08 0 0 0 3.04 0V12.7h2.26z"/>

					</svg>

				</a>

			<?php endif; ?>


			<?php if ( $tm_linkedin ) : ?>

				<a href="<?php echo esc_url( $tm_linkedin ); ?>" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; justify-content: center;">

					<svg width="24" height="24" viewBox="0 0 24 24">

						<rect width="24" height="24" rx="4" fill="#0A66C2"/>
						<path fill="#FFFFFF" d="M19 19h-3v-4.74c0-1.42-.56-2.39-1.83-2.39-.97 0-1.55.65-1.8 1.28-.09.23-.08.55-.08.87V19h-3s.04-9.2 0-10.15h3v1.44c.4-.61 1.11-1.48 2.7-1.48 1.97 0 3.46 1.29 3.46 4.07V19zM5.33 7.43c1.05 0 1.7-.69 1.7-1.56-.02-.89-.65-1.56-1.68-1.56-1.03 0-1.7.67-1.7 1.56 0 .87.65 1.56 1.66 1.56h.02zm-1.5 11.57h3V8.85h-3V19z"/>

					</svg>

				</a>

			<?php endif; ?>


			<?php if ( $tm_youtube ) : ?>

				<a href="<?php echo esc_url( $tm_youtube ); ?>" aria-label="YouTube" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; justify-content: center;">

					<svg width="24" height="24" viewBox="0 0 24 24">

						<path fill="#FF0000" d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814z"/>
						<polygon fill="#FFFFFF" points="9.545,15.568 15.818,12 9.545,8.432"/>

					</svg>

				</a>

			<?php endif; ?>


			<?php if ( $tm_x ) : ?>

				<a href="<?php echo esc_url( $tm_x ); ?>" aria-label="X (Twitter)" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; justify-content: center; background-color: #000000; border-radius: 4px; padding: 2px;">

					<svg width="20" height="20" viewBox="0 0 24 24" fill="#FFFFFF">

						<path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>

					</svg>

				</a>

			<?php endif; ?>


			<!-- =================================================
			     MOBILE WHATSAPP
			     ICON ONLY + CLICKABLE
			     Opens WhatsApp enquiry.
			     ================================================= -->

			<a
				class="tm-whatsapp-mobile"
				href="<?php
					echo esc_url(
						'https://wa.me/91' . $tm_whatsapp_number .
						'?text=' .
						rawurlencode(
							'Hi, I would like to enquire about your products. Please share more details.'
						)
					);
				?>"
				aria-label="WhatsApp"
				target="_blank"
				rel="noopener noreferrer"
			>

				<svg width="24" height="24" viewBox="0 0 24 24">

					<circle cx="12" cy="12" r="12" fill="#25D366"/>

					<path fill="#FFFFFF" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.198-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.298-.497.099-.198.05-.372-.025-.521-.075-.149-.669-1.611-.916-2.206-.242-.579-.487-.5-.67-.51-.198-.008-.372-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>

					<path fill="#FFFFFF" d="M12.004 2.003a9.97 9.97 0 0 0-8.52 15.15L2.5 21.5l4.45-1.166A9.97 9.97 0 1 0 12.004 2.003zm0 18.13a8.14 8.14 0 0 1-4.15-1.137l-.298-.177-2.641.692.705-2.575-.194-.315a8.13 8.13 0 1 1 6.578 3.512z"/>

				</svg>

			</a>

		</div>

	</div>


	<small>
		<?php echo esc_html( $tm_copy ); ?>
	</small>

	<em>
		<?php echo esc_html( thirsty_molecule_mod( 'tm_footer_note', __( 'Formula, not folklore.', 'thirsty-molecule' ) ) ); ?>
	</em>

</footer>

<?php wp_footer(); ?>
</body>
</html>
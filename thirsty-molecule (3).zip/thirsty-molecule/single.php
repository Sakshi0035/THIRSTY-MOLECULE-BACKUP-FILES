<?php
/**
 * Single post template.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="site-main-inner<?php echo is_active_sidebar( 'sidebar-1' ) ? '' : ' no-sidebar'; ?>">
	<div>
		<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', 'single' );

			the_post_navigation(
				array(
					'prev_text' => '<span class="entry-meta">' . esc_html__( 'Previous', 'thirsty-molecule' ) . '</span> %title',
					'next_text' => '<span class="entry-meta">' . esc_html__( 'Next', 'thirsty-molecule' ) . '</span> %title',
				)
			);

			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		}
		?>
	</div>
	<?php get_sidebar(); ?>
</div>

<?php
get_footer();

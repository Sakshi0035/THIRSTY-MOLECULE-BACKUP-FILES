<?php
/**
 * 404 template.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<section class="error-404">
	<div>
		<h1><?php esc_html_e( '404', 'thirsty-molecule' ); ?></h1>
		<p><?php esc_html_e( 'This page evaporated. Hydration can only do so much.', 'thirsty-molecule' ); ?></p>
		<a class="btn-pill" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to the shop', 'thirsty-molecule' ); ?></a>
	</div>
</section>

<?php
get_footer();

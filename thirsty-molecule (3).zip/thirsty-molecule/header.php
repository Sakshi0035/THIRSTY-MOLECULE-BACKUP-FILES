<div class="tm-elementor-section tm-elementor-section--ticker">
	<div class="ticker" aria-hidden="true">
		<div>
			<span style="color: #26d0ce;">WE’RE LIVE! 40% OFF SITEWIDE — USE CODE: INTRO40</span>
			<b style="color: #26d0ce;">&#10022;</b>
			<span style="color: #26d0ce;">WE’RE LIVE! 40% OFF SITEWIDE — USE CODE: INTRO40</span>
			<b style="color: #26d0ce;">&#10022;</b>
			<span style="color: #26d0ce;">WE’RE LIVE! 40% OFF SITEWIDE — USE CODE: INTRO40</span>
			<b style="color: #26d0ce;">&#10022;</b>
			<span style="color: #26d0ce;">WE’RE LIVE! 40% OFF SITEWIDE — USE CODE: INTRO40</span>
			<b style="color: #26d0ce;">&#10022;</b>
			<span style="color: #26d0ce;">WE’RE LIVE! 40% OFF SITEWIDE — USE CODE: INTRO40</span>
			<b style="color: #26d0ce;">&#10022;</b>
		</div>
	</div>
</div>
<?php
/**
 * Site header.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

/*
 * ---------------------------------------------------------
 * THIRSTY MOLECULE HEADER DATA
 * ---------------------------------------------------------
 */

/* Cart data — read the real WooCommerce cart/session when available. */
$tm_cart_url = home_url( '/carttway/' );
$tm_cart_count = 0;

if ( function_exists( 'WC' ) ) {
    if ( WC()->session === null && method_exists( WC(), 'initialize_session' ) ) {
        WC()->initialize_session();
    }

    if ( WC()->cart === null && function_exists( 'wc_load_cart' ) ) {
        wc_load_cart();
    }

    if ( WC()->cart ) {
        $tm_cart_count = (int) WC()->cart->get_cart_contents_count();
    }
}

/* Exact site logo destination. */
$tm_home_url = home_url( '/' );

/* Account menu destinations — use dedicated pages when they exist,
 * with safe WooCommerce/fallback URLs when they do not. */
$tm_signup_login_page = get_page_by_path( 'signup-login' );
$tm_account_page      = get_page_by_path( 'account' );

$tm_signup_login_url = $tm_signup_login_page
    ? get_permalink( $tm_signup_login_page )
    : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/signup-login/' ) );

/* Logged-in users should never be sent back to the signup/login screen. */
if ( is_user_logged_in() ) {
    $tm_signup_login_url = $tm_home_url;
}

$tm_account_url = $tm_account_page
    ? get_permalink( $tm_account_page )
    : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/account/' ) );

/* Always use WordPress/WooCommerce's real logout URL with its nonce. */
$tm_logout_url = wp_logout_url( $tm_home_url );

/* Keep this variable for compatibility with the existing mobile markup. */
$tm_orders_url = function_exists( 'wc_get_account_endpoint_url' )
    ? wc_get_account_endpoint_url( 'orders' )
    : $tm_account_url;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="profile" href="https://gmpg.org/xfn/11" />

<?php wp_head(); ?>

<style id="tm-final-nav-spacing-fix">
/* FINAL DESKTOP NAV SPACING FIX */
@media (min-width: 1101px) {
	#tm-site-header .tm-menu {
		display: flex !important;
		flex-direction: row !important;
		flex-wrap: nowrap !important;
		align-items: center !important;
		justify-content: flex-end !important;
		gap: 0 !important;
		width: max-content !important;
		margin: 0 !important;
		padding: 0 !important;
	}

	#tm-site-header .tm-menu > li {
		flex: 0 0 auto !important;
		width: max-content !important;
		min-width: 0 !important;
		margin: 0 !important;
		padding: 0 !important;
	}

	/* Home and Shop: small, even spacing */
	#tm-site-header .tm-menu > li.tm-home-item + li.tm-shop-dropdown {
		margin-left: 18px !important;
	}

	/* Shop and The range: ONLY 10px apart */
	#tm-site-header .tm-menu > li.tm-shop-dropdown + li.tm-range-item {
		margin-left: 10px !important;
	}

	/* The remaining navigation items: small, even spacing */
	#tm-site-header .tm-menu > li.tm-range-item + li.tm-nav-item {
		margin-left: 18px !important;
	}

	#tm-site-header .tm-menu > li.tm-nav-item + li.tm-nav-item {
		margin-left: 18px !important;
	}

	#tm-site-header .tm-menu > li.tm-nav-item + li.tm-cta-item {
		margin-left: 18px !important;
	}

	#tm-site-header .tm-shop-dropdown {
		width: max-content !important;
		min-width: 0 !important;
	}

	#tm-site-header .tm-shop-toggle {
		width: max-content !important;
		min-width: 0 !important;
		margin: 0 !important;
	}
}
</style>

<style id="tm-contact-button-final-fix">
/* CONTACT US — FINAL BLACK BUTTON ONLY */
@media (min-width: 1101px) {
	#tm-site-header .tm-menu > li.tm-cta-item {
		margin-left: 18px !important;
		padding: 0 !important;
		background: transparent !important;
		border: 0 !important;
		box-shadow: none !important;
	}

	#tm-site-header .tm-menu > li.tm-cta-item > a.tm-contact-button {
		display: inline-flex !important;
		align-items: center !important;
		justify-content: center !important;
		box-sizing: border-box !important;
		width: auto !important;
		min-width: 0 !important;
		height: 42px !important;
		padding: 0 18px !important;
		margin: 0 !important;
		background: #000000 !important;
		background-color: #000000 !important;
		color: #ffffff !important;
		border: 2px solid #000000 !important;
		border-radius: 999px !important;
		font-size: 17px !important;
		font-weight: 700 !important;
		line-height: 1 !important;
		text-decoration: none !important;
		white-space: nowrap !important;
		-webkit-appearance: none !important;
		appearance: none !important;
		box-shadow: none !important;
	}

	#tm-site-header .tm-menu > li.tm-cta-item > a.tm-contact-button:hover,
	#tm-site-header .tm-menu > li.tm-cta-item > a.tm-contact-button:focus,
	#tm-site-header .tm-menu > li.tm-cta-item > a.tm-contact-button:active {
		background: #000000 !important;
		background-color: #000000 !important;
		color: #ffffff !important;
		border-color: #000000 !important;
		text-decoration: none !important;
	}
}
</style>

<style id="tm-contact-button-all-devices-fix">
/* CONTACT US — SAME BLACK ROUNDED BUTTON ON DESKTOP + MOBILE */
#tm-site-header .tm-contact-button,
#tm-site-header .tm-mobile-contact a {
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	box-sizing: border-box !important;
	background: #000000 !important;
	background-color: #000000 !important;
	color: #ffffff !important;
	border: 2px solid #000000 !important;
	border-radius: 999px !important;
	font-size: 17px !important;
	font-weight: 700 !important;
	line-height: 1 !important;
	text-decoration: none !important;
	white-space: nowrap !important;
	box-shadow: none !important;
}

#tm-site-header .tm-contact-button:hover,
#tm-site-header .tm-contact-button:focus,
#tm-site-header .tm-contact-button:active,
#tm-site-header .tm-mobile-contact a:hover,
#tm-site-header .tm-mobile-contact a:focus,
#tm-site-header .tm-mobile-contact a:active {
	background: #000000 !important;
	background-color: #000000 !important;
	color: #ffffff !important;
	border-color: #000000 !important;
}

@media (min-width: 1101px) {
	#tm-site-header .tm-contact-button {
		height: 42px !important;
		padding: 0 18px !important;
		width: auto !important;
	}
}

@media (max-width: 1100px) {
	#tm-site-header .tm-mobile-contact a {
		min-height: 44px !important;
		height: 44px !important;
		padding: 0 20px !important;
		width: 100% !important;
	}
}
</style>

<style id="tm-custom-search-dropdown-styles">
/* LIVE SEARCH RESULT DROPDOWN STYLING (DESKTOP) */
.tm-desktop-search-wrap {
	position: relative !important;
	display: inline-block !important;
}
.tm-desktop-search-results {
	position: absolute !important;
	top: calc(100% + 8px) !important;
	left: 0 !important;
	width: 280px !important;
	background: #ffffff !important;
	border: 1px solid #eeeeee !important;
	border-radius: 8px !important;
	box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
	z-index: 99999 !important;
	display: none;
	overflow: hidden !important;
}
.tm-desktop-search-results.is-active {
	display: block !important;
}
.tm-search-result-item {
	display: flex !important;
	align-items: center !important;
	gap: 12px !important;
	padding: 10px 14px !important;
	color: #111111 !important;
	text-decoration: none !important;
	font-size: 14px !important;
	font-weight: 600 !important;
	border-bottom: 1px solid #f5f5f7 !important;
	transition: background 0.2s ease !important;
}
.tm-search-result-item:last-child {
	border-bottom: none !important;
}
.tm-search-result-item:hover {
	background: #fff0f6 !important;
	color: var(--tm-pink) !important;
}
.tm-search-result-image {
	width: 36px !important;
	height: 36px !important;
	object-fit: cover !important;
	border-radius: 4px !important;
}
.tm-search-no-results {
	padding: 12px 14px !important;
	color: #666666 !important;
	font-size: 13px !important;
}
</style>

</head>

<body <?php body_class(); ?>>

<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content">
	<?php esc_html_e( 'Skip to content', 'thirsty-molecule' ); ?>
</a>

<header class="tm-header" id="tm-site-header">

<div class="tm-header-inner">

	<!-- =====================================================
	     LEFT SIDE
	     ===================================================== -->
	<div class="tm-header-left">

		<!-- MOBILE HAMBURGER -->
		<label
			for="tm-nav-toggle"
			class="tm-hamburger"
			aria-label="<?php esc_attr_e( 'Open Menu', 'thirsty-molecule' ); ?>"
		>
			<span></span>
			<span></span>
			<span></span>
		</label>

		<!-- DESKTOP ACCOUNT -->
		<div class="tm-account-wrap tm-desktop-account">
			<button
				type="button"
				class="tm-account-toggle"
				aria-expanded="false"
				aria-haspopup="true"
				aria-label="<?php esc_attr_e( 'Account menu', 'thirsty-molecule' ); ?>"
			>
				<svg class="tm-account-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
					<circle cx="12" cy="7.5" r="3.2" stroke="currentColor" stroke-width="1.35"/>
					<path d="M5.2 20C5.8 15.9 8.2 13.8 12 13.8C15.8 13.8 18.2 15.9 18.8 20" stroke="currentColor" stroke-width="1.35" stroke-linecap="round"/>
				</svg>
			</button>

			<div class="tm-account-menu" role="menu">
				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url( $tm_account_url ); ?>" role="menuitem">Account</a>
					<a href="<?php echo esc_url( $tm_logout_url ); ?>" role="menuitem">Logout</a>
				<?php else : ?>
					<a href="<?php echo esc_url( $tm_signup_login_url ); ?>" role="menuitem">Signup / Login</a>
				<?php endif; ?>
			</div>
		</div>

		<!-- DESKTOP CART -->
		<a
			class="tm-cart-link"
			href="<?php echo esc_url( $tm_cart_url ); ?>"
			aria-label="<?php esc_attr_e( 'Shopping Cart', 'thirsty-molecule' ); ?>"
		>
			<svg
				class="tm-cart-icon"
				width="26"
				height="26"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
				aria-hidden="true"
			>
				<path
					d="M3 4H5L7.2 15.2C7.4 16.2 8.3 17 9.3 17H17.5C18.5 17 19.3 16.3 19.6 15.4L21 9H6"
					stroke="currentColor"
					stroke-width="1.8"
					stroke-linecap="round"
					stroke-linejoin="round"
				/>
				<circle cx="9.5" cy="20" r="1.35" fill="currentColor" />
				<circle cx="17.5" cy="20" r="1.35" fill="currentColor" />
			</svg>

			<span
				class="tm-cart-count"
				data-tm-cart-count=""
				aria-label="<?php echo esc_attr( $tm_cart_count . ' items in cart' ); ?>"
			>
				<?php echo esc_html( $tm_cart_count ); ?>
			</span>
		</a>

		<!-- =========================================================
		 THIRSTY MOLECULE CUSTOM PRODUCT SEARCH
		 Searches the existing /shop-all/ page.
		 Does NOT use WooCommerce product search.
		 ========================================================= -->

		<!-- DESKTOP SEARCH -->
		<div class="tm-desktop-search-wrap">
			<form
				class="tm-desktop-search"
				role="search"
				method="get"
				action="<?php echo esc_url( home_url( '/shop-all/' ) ); ?>"
			>
				<svg
					class="tm-search-icon"
					width="20"
					height="20"
					viewBox="0 0 24 24"
					fill="none"
					xmlns="http://www.w3.org/2000/svg"
					aria-hidden="true"
				>
					<circle
						cx="11"
						cy="11"
						r="7"
						stroke="currentColor"
						stroke-width="1.8"
					/>
					<path
						d="M16.5 16.5L21 21"
						stroke="currentColor"
						stroke-width="1.8"
						stroke-linecap="round"
					/>
				</svg>

				<input
					type="search"
					name="tm_product_search"
					class="tm-desktop-search-input"
					placeholder="<?php esc_attr_e( 'Search...', 'thirsty-molecule' ); ?>"
					autocomplete="off"
					aria-label="<?php esc_attr_e( 'Search products', 'thirsty-molecule' ); ?>"
				/>
			</form>
			<div class="tm-desktop-search-results" id="tm-desktop-search-results"></div>
		</div>

		<!-- MOBILE SEARCH -->
		<button
			type="button"
			class="tm-mobile-search-button"
			id="tm-mobile-search-open"
			aria-label="<?php esc_attr_e( 'Search products', 'thirsty-molecule' ); ?>"
		>
			<svg
				width="25"
				height="25"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
				aria-hidden="true"
			>
				<circle
					cx="11"
					cy="11"
					r="7"
					stroke="currentColor"
					stroke-width="1.9"
				/>
				<path
					d="M16.5 16.5L21 21"
					stroke="currentColor"
					stroke-width="1.9"
					stroke-linecap="round"
				/>
			</svg>
		</button>

	</div>

	<!-- =====================================================
	 CENTER LOGO
	 ===================================================== -->

	<a
		class="tm-logo"
		href="<?php echo esc_url( $tm_home_url ); ?>"
		aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
	>
		<img
			src="https://thirstymolecule.com/wp-content/uploads/2026/08/ada8e540-5f8a-478c-95a6-9f468b619207.png"
			alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
			class="tm-logo-image"
			style="
				display:block;
				width:160px;
				max-width:160px;
				height:auto;
				object-fit:contain;
			"
		/>
	</a>

	<style> /* Mobile logo size only */ @media (max-width: 767px) { .tm-logo-image { width:110px !important; max-width:110px !important; height:auto !important; } } </style>

	<!-- =====================================================
	     RIGHT SIDE
	     ===================================================== -->
	<div class="tm-header-right">

		<!-- MOBILE ACCOUNT -->
		<div class="tm-account-wrap tm-mobile-account">
			<button
				type="button"
				class="tm-account-toggle"
				aria-expanded="false"
				aria-haspopup="true"
				aria-label="<?php esc_attr_e( 'Account menu', 'thirsty-molecule' ); ?>"
			>
				<svg class="tm-account-icon" width="29" height="29" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
					<circle cx="12" cy="7.5" r="3.2" stroke="currentColor" stroke-width="1.35"/>
					<path d="M5.2 20C5.8 15.9 8.2 13.8 12 13.8C15.8 13.8 18.2 15.9 18.8 20" stroke="currentColor" stroke-width="1.35" stroke-linecap="round"/>
				</svg>
			</button>

			<div class="tm-account-menu" role="menu">
				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url( $tm_account_url ); ?>" role="menuitem">Account</a>
					<a href="<?php echo esc_url( $tm_logout_url ); ?>" role="menuitem">Logout</a>
				<?php else : ?>
					<a href="<?php echo esc_url( $tm_signup_login_url ); ?>" role="menuitem">Signup / Login</a>
				<?php endif; ?>
			</div>
		</div>

		<!-- MOBILE CART -->
		<a
			class="tm-mobile-cart"
			href="<?php echo esc_url( $tm_cart_url ); ?>"
			aria-label="<?php esc_attr_e( 'Shopping Cart', 'thirsty-molecule' ); ?>"
		>
			<svg
				width="27"
				height="27"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
				aria-hidden="true"
			>
				<path
					d="M3 4H5L7.2 15.2C7.4 16.2 8.3 17 9.3 17H17.5C18.5 17 19.3 16.3 19.6 15.4L21 9H6"
					stroke="currentColor"
					stroke-width="1.8"
					stroke-linecap="round"
					stroke-linejoin="round"
				/>
				<circle cx="9.5" cy="20" r="1.35" fill="currentColor" />
				<circle cx="17.5" cy="20" r="1.35" fill="currentColor" />
			</svg>

			<span class="tm-cart-count" data-tm-cart-count="">
				<?php echo esc_html( $tm_cart_count ); ?>
			</span>
		</a>


		<!-- =================================================
		     DESKTOP NAVIGATION
		     ================================================= -->
		<nav
			id="primary-navigation"
			class="tm-primary-navigation"
			aria-label="<?php esc_attr_e( 'Primary', 'thirsty-molecule' ); ?>"
		>
			<ul class="tm-menu">

				<!-- HOME -->
				<li class="tm-nav-item tm-home-item">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<span class="tm-link-text">
							<?php esc_html_e( 'Home', 'thirsty-molecule' ); ?>
						</span>
					</a>
				</li>


				<!-- SHOP -->
				<li class="tm-shop-dropdown">

					<button
						type="button"
						class="tm-shop-toggle"
						aria-expanded="false"
						aria-controls="tm-shop-panel"
					>
						<span class="tm-link-text">
							<?php esc_html_e( 'Shop', 'thirsty-molecule' ); ?>
						</span>

						<svg
							class="tm-arrow"
							width="10"
							height="7"
							viewBox="0 0 14 9"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
							aria-hidden="true"
						>
							<path
								d="M1.5 1.5L7 7L12.5 1.5"
								stroke="currentColor"
								stroke-width="2.2"
								stroke-linecap="round"
								stroke-linejoin="round"
							/>
						</svg>
					</button>

					<ul class="tm-shop-panel" id="tm-shop-panel">

						<li>
							<a href="<?php echo esc_url( home_url( '/shop-all/' ) ); ?>">
								<?php esc_html_e( 'Shop All', 'thirsty-molecule' ); ?>
							</a>
						</li>

						<li>
							<a href="<?php echo esc_url( home_url( '/bestsellers/' ) ); ?>">
								<?php esc_html_e( 'Bestsellers', 'thirsty-molecule' ); ?>
							</a>
						</li>
						
						<!-- SHOP BY CATEGORY — TEMPORARILY DISABLED -->
						<?php if ( false ) : ?>
						<!-- SHOP BY CATEGORY -->
						<li class="tm-submenu">

							<button
								type="button"
								class="tm-submenu-header"
								aria-expanded="false"
							>
								<span>
									<?php esc_html_e( 'Shop by Category', 'thirsty-molecule' ); ?>
								</span>

								<svg
									class="tm-sub-arrow"
									width="10"
									height="7"
									viewBox="0 0 14 9"
									fill="none"
									xmlns="http://www.w3.org/2000/svg"
									aria-hidden="true"
								>
									<path
										d="M1.5 1.5L7 7L12.5 1.5"
										stroke="currentColor"
										stroke-width="2.2"
										stroke-linecap="round"
										stroke-linejoin="round"
									/>
								</svg>
							</button>

							<ul class="tm-submenu-dropdown">
								<li>
									<a href="<?php echo esc_url( home_url( '/skincare/' ) ); ?>">
										Skincare
									</a>
								</li>
							</ul>
							<?php endif; ?>

						</li>
						
						<!-- SHOP BY PRODUCT — TEMPORARILY DISABLED -->
						<?php if ( false ) : ?>
						<!-- SHOP BY PRODUCT -->
						<li class="tm-submenu">

							<button
								type="button"
								class="tm-submenu-header"
								aria-expanded="false"
							>
								<span>
									<?php esc_html_e( 'Shop by Product', 'thirsty-molecule' ); ?>
								</span>

								<svg
									class="tm-sub-arrow"
									width="10"
									height="7"
									viewBox="0 0 14 9"
									fill="none"
									xmlns="http://www.w3.org/2000/svg"
									aria-hidden="true"
								>
									<path
										d="M1.5 1.5L7 7L12.5 1.5"
										stroke="currentColor"
										stroke-width="2.2"
										stroke-linecap="round"
										stroke-linejoin="round"
									/>
								</svg>
							</button>

							<ul class="tm-submenu-dropdown">
								<li><a href="<?php echo esc_url( home_url( '/cleansers/' ) ); ?>">Cleansers</a></li>
								<li><a href="<?php echo esc_url( home_url( '/moisturizers/' ) ); ?>">Moisturisers</a></li>
							</ul>
							<?php endif; ?>

						</li>

						<?php if ( false ) : ?>
						<!-- SHOP BY CONCERN — TEMPORARILY DISABLED -->
						<li class="tm-submenu">

							<button
								type="button"
								class="tm-submenu-header"
								aria-expanded="false"
							>
								<span>
									<?php esc_html_e( 'Shop by Concern', 'thirsty-molecule' ); ?>
								</span>

								<svg
									class="tm-sub-arrow"
									width="10"
									height="7"
									viewBox="0 0 14 9"
									fill="none"
									xmlns="http://www.w3.org/2000/svg"
									aria-hidden="true"
								>
									<path
										d="M1.5 1.5L7 7L12.5 1.5"
										stroke="currentColor"
										stroke-width="2.2"
										stroke-linecap="round"
										stroke-linejoin="round"
									/>
								</svg>
							</button>

							<ul class="tm-submenu-dropdown">
								<li><a href="<?php echo esc_url( home_url( '/concern/dark-spots-pigmentation/' ) ); ?>">Dark Spots &amp; Pigmentation</a></li>
								<li><a href="<?php echo esc_url( home_url( '/concern/dry-dehydrated-skin/' ) ); ?>">Dry &amp; Dehydrated Skin</a></li>
								<li><a href="<?php echo esc_url( home_url( '/concern/sensitive-skin/' ) ); ?>">Sensitive Skin</a></li>
								<li><a href="<?php echo esc_url( home_url( '/concern/anti-ageing/' ) ); ?>">Anti-Ageing</a></li>
								<li><a href="<?php echo esc_url( home_url( '/concern/oily-acne-prone-skin/' ) ); ?>">Oily &amp; Acne-Prone Skin</a></li>
							</ul>

						</li>
						<?php endif; ?>

					</ul>

				</li>


				<!-- THE RANGE -->
				<li class="tm-nav-item tm-range-item">
					<a href="<?php echo esc_url( home_url( '/#range' ) ); ?>">
						<span class="tm-link-text">
							<?php esc_html_e( 'The Range', 'thirsty-molecule' ); ?>
						</span>
					</a>
				</li>


				<!-- OUR STORY -->
				<li class="tm-nav-item">
					<a href="<?php echo esc_url( home_url( '/#story' ) ); ?>">
						<span class="tm-link-text">
							<?php esc_html_e( 'Our Story', 'thirsty-molecule' ); ?>
						</span>
					</a>
				</li>


				<!-- WHY US -->
				<li class="tm-nav-item">
					<a href="<?php echo esc_url( home_url( '/#why' ) ); ?>">
						<span class="tm-link-text">
							<?php esc_html_e( 'Why Us', 'thirsty-molecule' ); ?>
						</span>
					</a>
				</li>


				<!-- CONTACT US -->
			<li class="tm-cta-item">
				<a
					class="tm-contact-button"
					href="#tm-footer-help"
				>
					<?php
					if ( function_exists( 'thirsty_molecule_mod' ) ) {
						echo esc_html(
							thirsty_molecule_mod(
								'tm_nav_cta_label',
								__( 'Contact Us', 'thirsty-molecule' )
							)
						);
					} else {
						esc_html_e( 'Contact Us', 'thirsty-molecule' );
					}
					?>
				</a>
			</li>

		</ul>
	</nav>

</div>

</div>
	
<!-- =====================================================
     MOBILE MENU
     ===================================================== -->

<input
	type="checkbox"
	id="tm-nav-toggle"
	class="tm-nav-toggle"
	aria-hidden="false"
/>

<!-- BACKDROP (Overlay for tapping outside drawer) -->
<label
	for="tm-nav-toggle"
	class="tm-nav-backdrop"
	aria-label="<?php esc_attr_e( 'Close Menu', 'thirsty-molecule' ); ?>"
></label>


<aside
	class="tm-mobile-drawer"
	id="tm-mobile-drawer"
	aria-label="<?php esc_attr_e( 'Mobile Navigation', 'thirsty-molecule' ); ?>"
>

	<label
		for="tm-nav-toggle"
		class="tm-mobile-close-btn"
		aria-label="<?php esc_attr_e( 'Close Menu', 'thirsty-molecule' ); ?>"
	>
		<svg
			width="21"
			height="21"
			viewBox="0 0 24 24"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
			aria-hidden="true"
		>
			<path
				d="M6 6L18 18"
				stroke="currentColor"
				stroke-width="2.3"
				stroke-linecap="round"
			/>
			<path
				d="M18 6L6 18"
				stroke="currentColor"
				stroke-width="2.3"
				stroke-linecap="round"
			/>
		</svg>
	</label>


	<nav class="tm-mobile-navigation">

		<ul class="tm-mobile-menu">

			<li>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
					Home
				</a>
			</li>


			<li class="tm-mobile-shop">

				<button
					type="button"
					class="tm-mobile-shop-toggle"
					aria-expanded="false"
				>
					<span>Shop</span>

					<svg
						width="11"
						height="7"
						viewBox="0 0 14 9"
						fill="none"
						xmlns="http://www.w3.org/2000/svg"
						aria-hidden="true"
					>
						<path
							d="M1.5 1.5L7 7L12.5 1.5"
							stroke="currentColor"
							stroke-width="2.2"
							stroke-linecap="round"
							stroke-linejoin="round"
						/>
					</svg>
				</button>


				<div class="tm-mobile-shop-panel">

					<a href="<?php echo esc_url( home_url( '/shop-all/' ) ); ?>">
						Shop All
					</a>

					<a href="<?php echo esc_url( home_url( '/bestsellers/' ) ); ?>">
						Bestsellers
					</a>
					
					<!-- SHOP BY Category — TEMPORARILY DISABLED -->
					<?php if ( false ) : ?>
					<div class="tm-mobile-submenu">

						<button
							type="button"
							class="tm-mobile-submenu-toggle"
							aria-expanded="false"
						>
							<span>Shop by Category</span>

							<svg
								width="10"
								height="7"
								viewBox="0 0 14 9"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
								aria-hidden="true"
							>
								<path
									d="M1.5 1.5L7 7L12.5 1.5"
									stroke="currentColor"
									stroke-width="2"
									stroke-linecap="round"
									stroke-linejoin="round"
								/>
							</svg>
						</button>

						<div class="tm-mobile-submenu-content">
							<a href="<?php echo esc_url( home_url( '/skincare/' ) ); ?>">Skincare</a>
						</div>
						<?php endif; ?>

					</div>
					
					<!-- SHOP BY PRODUCT — TEMPORARILY DISABLED -->
					<?php if ( false ) : ?>
					<div class="tm-mobile-submenu">

						<button
							type="button"
							class="tm-mobile-submenu-toggle"
							aria-expanded="false"
						>
							<span>Shop by Product</span>

							<svg
								width="10"
								height="7"
								viewBox="0 0 14 9"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
								aria-hidden="true"
							>
								<path
									d="M1.5 1.5L7 7L12.5 1.5"
									stroke="currentColor"
									stroke-width="2"
									stroke-linecap="round"
									stroke-linejoin="round"
								/>
							</svg>
						</button>

						<div class="tm-mobile-submenu-content">
							<a href="<?php echo esc_url( home_url( '/cleansers/' ) ); ?>">Cleansers</a>
							<a href="<?php echo esc_url( home_url( '/moisturizers/' ) ); ?>">Moisturisers</a>
						</div>
						<?php endif; ?>

					</div>


					<!-- SHOP BY CONCERN — TEMPORARILY DISABLED -->
					<?php if ( false ) : ?>
					<div class="tm-mobile-submenu">

						<button
							type="button"
							class="tm-mobile-submenu-toggle"
							aria-expanded="false"
						>
							<span>Shop by Concern</span>

							<svg
								width="10"
								height="7"
								viewBox="0 0 14 9"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
								aria-hidden="true"
							>
								<path
									d="M1.5 1.5L7 7L12.5 1.5"
									stroke="currentColor"
									stroke-width="2"
									stroke-linecap="round"
									stroke-linejoin="round"
								/>
							</svg>
						</button>

						<div class="tm-mobile-submenu-content">
							<a href="<?php echo esc_url( home_url( '/concern/dark-spots-pigmentation/' ) ); ?>">Dark Spots &amp; Pigmentation</a>
							<a href="<?php echo esc_url( home_url( '/concern/dry-dehydrated-skin/' ) ); ?>">Dry &amp; Dehydrated Skin</a>
							<a href="<?php echo esc_url( home_url( '/concern/sensitive-skin/' ) ); ?>">Sensitive Skin</a>
							<a href="<?php echo esc_url( home_url( '/concern/anti-ageing/' ) ); ?>">Anti-Ageing</a>
							<a href="<?php echo esc_url( home_url( '/concern/oily-acne-prone-skin/' ) ); ?>">Oily &amp; Acne-Prone Skin</a>
						</div>

					</div>
					<?php endif; ?>

				</div>

			</li>


			<li>
				<a href="<?php echo esc_url( home_url( '/#range' ) ); ?>">
					The Range
				</a>
			</li>

			<li>
				<a href="<?php echo esc_url( home_url( '/#story' ) ); ?>">
					Our Story
				</a>
			</li>

			<li>
				<a href="<?php echo esc_url( home_url( '/#why' ) ); ?>">
					Why Us
				</a>
			</li>


			<li class="tm-mobile-contact">
			<a
				href="#tm-footer-help"
			>
				<?php
				if ( function_exists( 'thirsty_molecule_mod' ) ) {
					echo esc_html(
						thirsty_molecule_mod(
							'tm_nav_cta_label',
							__( 'Contact Us', 'thirsty-molecule' )
						)
					);
				} else {
					esc_html_e( 'Contact Us', 'thirsty-molecule' );
				}
				?>
			</a>

		</li>

	</ul>

</nav>
</aside>

<!-- =====================================================
     MOBILE SEARCH
     ===================================================== -->

<div
	class="tm-mobile-search-panel"
	id="tm-mobile-search-panel"
	aria-hidden="true"
>

	<div class="tm-mobile-search-header">

		<button
			type="button"
			class="tm-mobile-search-close"
			id="tm-mobile-search-close"
			aria-label="<?php esc_attr_e( 'Close Search', 'thirsty-molecule' ); ?>"
		>
			<svg
				width="22"
				height="22"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M6 6L18 18"
					stroke="currentColor"
					stroke-width="2.2"
					stroke-linecap="round"
				/>
				<path
					d="M18 6L6 18"
					stroke="currentColor"
					stroke-width="2.2"
					stroke-linecap="round"
				/>
			</svg>
		</button>

		<span>Search</span>

	</div>


	<form
		class="tm-mobile-search-form"
		id="tm-mobile-search-form"
	>

		<div class="tm-mobile-search-input-wrap">

			<svg
				width="22"
				height="22"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<circle
					cx="11"
					cy="11"
					r="7"
					stroke="currentColor"
					stroke-width="1.8"
				/>
				<path
					d="M16.5 16.5L21 21"
					stroke="currentColor"
					stroke-width="1.8"
					stroke-linecap="round"
				/>
			</svg>

			<input
				type="search"
				id="tm-mobile-search-input"
				placeholder="Search products..."
				autocomplete="off"
				aria-label="Search products"
			/>

		</div>

		<button type="submit">
			Search
		</button>

	</form>


	<div
		class="tm-mobile-search-status"
		id="tm-mobile-search-status"
	></div>

	<div
		class="tm-mobile-search-results"
		id="tm-mobile-search-results"
	></div>

</div>

</header>

<style id="tm-header-inline">
/* =========================================================
   THIRSTY MOLECULE HEADER
   ========================================================= */
:root {
	--tm-pink: #e5006d;
	--tm-pink-hover: #ff0a7a;
	--tm-black: #000000;
	--tm-white: #ffffff;
	--tm-border: #eeeeee;
	--tm-soft: #f6f6f8;
}

/* =========================================================
   GLOBAL HEADER RESET
   ========================================================= */
.tm-header,
.tm-header *,
.tm-mobile-drawer,
.tm-mobile-drawer *,
.tm-mobile-search-panel,
.tm-mobile-search-panel * {
	box-sizing: border-box !important;
}

.tm-header a {
	text-decoration: none !important;
}

/* =========================================================
   HEADER
   ========================================================= */
.tm-header {
	position: relative !important;
	width: 100% !important;
	background: #ffffff !important;
	border-bottom: 1px solid #eeeeee !important;
	z-index: 9000 !important;
}

.tm-header-inner {
	position: relative !important;
	width: 100% !important;
	min-height: 120px !important;
	padding: 0 2.5rem !important;
	display: grid !important;
	grid-template-columns: minmax(0, 1fr) 180px minmax(0, 1fr) !important;
	align-items: center !important;
	column-gap: 20px !important;
}

/* =========================================================
   LEFT SIDE
   ========================================================= */
.tm-header-left {
	grid-column: 1 !important;
	display: flex !important;
	align-items: center !important;
	justify-content: flex-start !important;
	gap: 1.2rem !important;
	min-width: 0 !important;
	width: 100% !important;
	z-index: 20 !important;
}

/* =========================================================
   ACCOUNT ICON + ACCOUNT MENU
   ========================================================= */
.tm-account-wrap {
	position: relative !important;
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	flex: 0 0 34px !important;
	z-index: 100005 !important;
}

.tm-account-toggle {
	position: relative !important;
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	width: 34px !important;
	height: 34px !important;
	padding: 0 !important;
	margin: 0 !important;
	background: transparent !important;
	border: 0 !important;
	border-radius: 0 !important;
	box-shadow: none !important;
	color: #000000 !important;
	cursor: pointer !important;
	-webkit-appearance: none !important;
	appearance: none !important;
}

.tm-account-icon {
	display: block !important;
	width: 28px !important;
	height: 28px !important;
	color: currentColor !important;
}

.tm-account-toggle:hover,
.tm-account-toggle:focus,
.tm-account-toggle:active {
	background: transparent !important;
	color: var(--tm-pink) !important;
	outline: none !important;
	box-shadow: none !important;
}

.tm-account-menu {
	position: absolute !important;
	top: calc(100% + 12px) !important;
	left: 50% !important;
	transform: translateX(-50%) translateY(-5px) !important;
	width: 178px !important;
	padding: 7px 0 !important;
	background: #ffffff !important;
	border: 1px solid #e8e8e8 !important;
	border-top: 3px solid var(--tm-pink) !important;
	border-radius: 8px !important;
	box-shadow: 0 14px 32px rgba(0,0,0,0.14) !important;
	opacity: 0 !important;
	visibility: hidden !important;
	pointer-events: none !important;
	z-index: 100006 !important;
	transition: opacity 0.18s ease, transform 0.18s ease, visibility 0.18s ease !important;
}

.tm-account-wrap.is-open .tm-account-menu {
	opacity: 1 !important;
	visibility: visible !important;
	pointer-events: auto !important;
	transform: translateX(-50%) translateY(0) !important;
}

.tm-account-menu a {
	display: flex !important;
	align-items: center !important;
	min-height: 42px !important;
	width: 100% !important;
	box-sizing: border-box !important;
	padding: 8px 16px !important;
	color: #111111 !important;
	font-family: inherit !important;
	font-size: 14px !important;
	font-weight: 700 !important;
	line-height: 1.2 !important;
	text-decoration: none !important;
	white-space: nowrap !important;
}

.tm-account-menu a:hover,
.tm-account-menu a:focus {
	background: #fff0f6 !important;
	color: var(--tm-pink) !important;
	text-decoration: none !important;
}

.tm-mobile-account {
	display: none !important;
}

.tm-cart-link {
	position: relative !important;
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	width: 34px !important;
	height: 34px !important;
	color: #000000 !important;
	flex: 0 0 34px !important;
}

.tm-cart-icon {
	display: block !important;
	width: 27px !important;
	height: 27px !important;
}

.tm-cart-count,
.tm-mobile-cart .tm-cart-count {
	position: absolute !important;
	top: -5px !important;
	right: -7px !important;
	min-width: 20px !important;
	height: 20px !important;
	padding: 0 5px !important;
	display: flex !important;
	align-items: center !important;
	justify-content: center !important;
	background: var(--tm-pink) !important;
	color: #ffffff !important;
	border-radius: 999px !important;
	font-size: 11px !important;
	font-weight: 800 !important;
	line-height: 1 !important;
}

.tm-desktop-search {
	width: 210px !important;
	height: 44px !important;
	display: flex !important;
	align-items: center !important;
	gap: 10px !important;
	padding: 0 16px !important;
	background: #f5f5f7 !important;
	border-radius: 999px !important;
	flex: 0 1 210px !important;
	min-width: 0 !important;
}

.tm-search-icon {
	color: #666666 !important;
	flex: 0 0 auto !important;
}

.tm-desktop-search-input {
	width: 100% !important;
	min-width: 0 !important;
	padding: 0 !important;
	margin: 0 !important;
	border: 0 !important;
	outline: 0 !important;
	background: transparent !important;
	color: #222222 !important;
	font-family: inherit !important;
	font-size: 15px !important;
	line-height: 1 !important;
	box-shadow: none !important;
}

/* =========================================================
   CENTER LOGO
   ========================================================= */
.tm-logo {
	grid-column: 2 !important;
	position: relative !important;
	left: auto !important;
	top: auto !important;
	transform: none !important;
	display: flex !important;
	flex-direction: column !important;
	align-items: center !important;
	justify-content: center !important;
	width: 180px !important;
	height: auto !important;
	margin: 0 auto !important;
	padding: 0 !important;
	color: var(--tm-pink) !important;
	font-family: Georgia, "Times New Roman", serif !important;
	font-size: 22px !important;
	font-weight: 700 !important;
	line-height: 0.82 !important;
	letter-spacing: -0.7px !important;
	text-align: center !important;
	white-space: nowrap !important;
	z-index: 30 !important;
}

.tm-logo span {
	display: block !important;
	margin: 0 !important;
	padding: 0 !important;
}

/* =========================================================
   RIGHT SIDE
   ========================================================= */
.tm-header-right {
	grid-column: 3 !important;
	display: flex !important;
	align-items: center !important;
	justify-content: flex-end !important;
	min-width: 0 !important;
	width: 100% !important;
	z-index: 20 !important;
}

/* =========================================================
   DESKTOP NAVIGATION (STRICT FLEX LAYOUT TO PREVENT OVERLAP)
   ========================================================= */
.tm-primary-navigation {
	display: block !important;
	width: auto !important;
	max-width: 100% !important;
	flex: 0 0 auto !important;
	min-width: 0 !important;
}

.tm-menu {
	display: flex !important;
	flex-direction: row !important;
	flex-wrap: nowrap !important;
	align-items: center !important;
	justify-content: flex-end !important;
	gap: 1.5rem !important;
	width: max-content !important;
	max-width: 100% !important;
	list-style: none !important;
	margin: 0 !important;
	padding: 0 !important;
	white-space: nowrap !important;
}

/* OVERLAP FIX: Force exact relative inline-flex ordering on every LI */
.tm-menu > li,
.tm-menu > li.tm-shop-dropdown,
.tm-menu > li.tm-range-item,
.tm-menu > li.tm-nav-item {
	position: relative !important;
	top: auto !important;
	left: auto !important;
	right: auto !important;
	bottom: auto !important;
	float: none !important;
	transform: none !important;
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	flex: 0 0 auto !important;
	margin: 0 !important;
	padding: 0 !important;
	height: 44px !important;
	list-style: none !important;
	background: transparent !important;
	box-shadow: none !important;
	border: none !important;
	vertical-align: middle !important;
}

/* =========================================================
   NORMAL NAV LINKS
   ========================================================= */
.tm-menu > li > a {
	position: relative !important;
	top: auto !important;
	left: auto !important;
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	width: auto !important;
	min-width: max-content !important;
	height: 44px !important;
	padding: 0 !important;
	margin: 0 !important;
	background: transparent !important;
	border: none !important;
	border-radius: 0 !important;
	box-shadow: none !important;
	color: #000000 !important;
	font-family: inherit !important;
	font-size: 15px !important;
	font-weight: 700 !important;
	line-height: 1 !important;
	white-space: nowrap !important;
	cursor: pointer !important;
	text-decoration: none !important;
	transition: color 0.2s ease !important;
}

/* =========================================================
   SHOP BUTTON FIX FOR SIDE-BY-SIDE ALIGNMENT
   ========================================================= */
#tm-site-header .tm-primary-navigation button.tm-shop-toggle,
.tm-shop-dropdown button.tm-shop-toggle,
.tm-shop-toggle {
	all: unset !important;
	box-sizing: border-box !important;
	position: relative !important;
	top: auto !important;
	left: auto !important;
	float: none !important;
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	gap: 5px !important;
	width: auto !important;
	min-width: max-content !important;
	height: 44px !important;
	padding: 0 !important;
	margin: 0 !important;
	background: transparent !important;
	background-color: transparent !important;
	border: none !important;
	border-radius: 0 !important;
	box-shadow: none !important;
	color: #000000 !important;
	font-family: inherit !important;
	font-size: 15px !important;
	font-weight: 700 !important;
	line-height: 1 !important;
	white-space: nowrap !important;
	cursor: pointer !important;
	flex: 0 0 auto !important;
	vertical-align: middle !important;
	transition: color 0.2s ease !important;
}

#tm-site-header .tm-primary-navigation .tm-shop-toggle::before,
#tm-site-header .tm-primary-navigation .tm-shop-toggle::after {
	content: none !important;
	display: none !important;
}

.tm-menu > li > a:hover,
#tm-site-header .tm-primary-navigation button.tm-shop-toggle:hover {
	color: var(--tm-pink) !important;
	background: transparent !important;
	background-color: transparent !important;
}

/* =========================================================
   ARROWS
   ========================================================= */
.tm-arrow,
.tm-sub-arrow {
	display: inline-block !important;
	flex: 0 0 auto !important;
	margin: 0 !important;
	transition: transform 0.2s ease, color 0.2s ease !important;
}

.tm-shop-dropdown.is-open .tm-arrow {
	transform: rotate(180deg) !important;
	color: var(--tm-pink) !important;
}

/* =========================================================
   CONTACT BUTTON
   ========================================================= */
.tm-cta-item {
	flex: 0 0 auto !important;
}

.tm-contact-button {
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	width: max-content !important;
	min-width: max-content !important;
	height: 44px !important;
	padding: 0 20px !important;
	background: #000000 !important;
	color: #ffffff !important;
	border: 2px solid #000000 !important;
	border-radius: 999px !important;
	font-family: inherit !important;
	font-size: 15px !important;
	font-weight: 700 !important;
	line-height: 1 !important;
	white-space: nowrap !important;
	cursor: pointer !important;
	flex: 0 0 auto !important;
	transition: background 0.2s ease, border-color 0.2s ease, transform 0.2s ease !important;
}

.tm-contact-button:hover {
	background: var(--tm-pink) !important;
	border-color: var(--tm-pink) !important;
	color: #ffffff !important;
	transform: translateY(-1px) !important;
}

/* =========================================================
   SHOP DROPDOWN PANEL
   ========================================================= */
.tm-shop-panel {
	position: absolute !important;
	top: calc(100% + 4px) !important;
	left: 0 !important;
	width: 245px !important;
	display: block !important;
	visibility: hidden !important;
	opacity: 0 !important;
	pointer-events: none !important;
	list-style: none !important;
	margin: 0 !important;
	padding: 9px 0 !important;
	background: #ffffff !important;
	border: 1px solid #eeeeee !important;
	border-top: 3px solid var(--tm-pink) !important;
	border-radius: 7px !important;
	box-shadow: 0 16px 35px rgba(0, 0, 0, 0.12) !important;
	z-index: 99999 !important;
	transition: opacity 0.18s ease, transform 0.18s ease, visibility 0.18s ease !important;
}

.tm-shop-dropdown.is-open > .tm-shop-panel {
	visibility: visible !important;
	opacity: 1 !important;
	pointer-events: auto !important;
}

.tm-shop-panel > li {
	position: relative !important;
	display: block !important;
	margin: 0 !important;
	padding: 0 !important;
	height: auto !important;
	list-style: none !important;
}

.tm-shop-panel > li > a {
	display: flex !important;
	align-items: center !important;
	width: 100% !important;
	min-height: 42px !important;
	padding: 9px 17px !important;
	color: #111111 !important;
	font-size: 14px !important;
	font-weight: 600 !important;
	line-height: 1.25 !important;
	white-space: nowrap !important;
	text-decoration: none !important;
}

.tm-shop-panel > li > a:hover {
	background: #fff0f6 !important;
	color: var(--tm-pink) !important;
}

/* =========================================================
   DESKTOP SUBMENUS
   ========================================================= */
.tm-submenu-header {
	width: 100% !important;
	min-height: 42px !important;
	display: flex !important;
	align-items: center !important;
	justify-content: space-between !important;
	padding: 9px 17px !important;
	margin: 0 !important;
	background: transparent !important;
	border: 0 !important;
	color: #111111 !important;
	font-size: 14px !important;
	font-weight: 600 !important;
	text-align: left !important;
	cursor: pointer !important;
}

.tm-submenu-header:hover,
.tm-submenu.is-open > .tm-submenu-header {
	background: #fff0f6 !important;
	color: var(--tm-pink) !important;
}

.tm-submenu.is-open .tm-sub-arrow {
	transform: rotate(180deg) !important;
	color: var(--tm-pink) !important;
}

.tm-submenu-dropdown {
	position: absolute !important;
	top: -4px !important;
	left: calc(100% + 5px) !important;
	width: 235px !important;
	display: block !important;
	visibility: hidden !important;
	opacity: 0 !important;
	pointer-events: none !important;
	list-style: none !important;
	margin: 0 !important;
	padding: 8px 0 !important;
	background: #ffffff !important;
	border: 1px solid #eeeeee !important;
	border-top: 3px solid var(--tm-pink) !important;
	border-radius: 7px !important;
	box-shadow: 0 16px 35px rgba(0,0,0,0.12) !important;
	z-index: 100000 !important;
	transition: opacity 0.18s ease, visibility 0.18s ease !important;
}

.tm-submenu.is-open > .tm-submenu-dropdown {
	visibility: visible !important;
	opacity: 1 !important;
	pointer-events: auto !important;
}

.tm-submenu-dropdown a {
	display: block !important;
	width: 100% !important;
	padding: 9px 16px !important;
	color: #111111 !important;
	font-size: 13px !important;
	font-weight: 500 !important;
	line-height: 1.3 !important;
	text-decoration: none !important;
}

.tm-submenu-dropdown a:hover {
	background: #fff0f6 !important;
	color: var(--tm-pink) !important;
}

/* =========================================================
   MOBILE ELEMENTS HIDDEN ON DESKTOP
   ========================================================= */
.tm-hamburger,
.tm-mobile-search-button,
.tm-mobile-cart,
.tm-mobile-account,
.tm-mobile-drawer,
.tm-nav-toggle,
.tm-nav-backdrop,
.tm-mobile-search-panel {
	display: none !important;
}

/* =========================================================
   DESKTOP LEFT CONTROLS — MOVE SLIGHTLY INSIDE THE SCREEN
   Keeps account + cart + search comfortably away from the
   extreme left edge on desktop only. Mobile is untouched.
   ========================================================= */
@media (min-width: 1101px) {
	.tm-header-left {
		padding-left: 34px !important;
		box-sizing: border-box !important;
	}
}

/* =========================================================
   DESKTOP RESPONSIVE BREAKPOINTS
   ========================================================= */
@media (min-width: 1101px) and (max-width: 1400px) {
	.tm-header-inner {
		padding-left: 1.5rem !important;
		padding-right: 1.5rem !important;
		grid-template-columns: minmax(0, 1fr) 170px minmax(0, 1fr) !important;
		column-gap: 12px !important;
	}

	.tm-logo {
		width: 170px !important;
		font-size: 21px !important;
	}

	.tm-menu {
		gap: 0.95rem !important;
	}

	.tm-menu > li > a,
	#tm-site-header .tm-primary-navigation button.tm-shop-toggle {
		font-size: 14px !important;
	}

	.tm-contact-button {
		height: 42px !important;
		padding-left: 16px !important;
		padding-right: 16px !important;
		font-size: 14px !important;
	}

	.tm-desktop-search {
		width: 175px !important;
		flex-basis: 175px !important;
	}
}

/* =========================================================
   TABLET / NARROW DESKTOP
   ========================================================= */
@media (max-width: 1100px), screen and (max-device-width: 1100px) {
	.tm-header-inner {
		display: flex !important;
		min-height: 70px !important;
		padding: 0 18px !important;
		align-items: center !important;
		justify-content: space-between !important;
	}

	.tm-logo {
		position: absolute !important;
		left: 50% !important;
		top: 50% !important;
		transform: translate(-50%, -50%) !important;
		width: auto !important;
		font-size: 17px !important;
		line-height: 0.84 !important;
		letter-spacing: -0.4px !important;
		z-index: 30 !important;
	}

	.tm-header-left {
		display: flex !important;
		width: auto !important;
		gap: 0 !important;
		z-index: 40 !important;
	}

	.tm-header-left .tm-cart-link,
	.tm-desktop-search-wrap,
	.tm-primary-navigation {
		display: none !important;
	}

	.tm-hamburger {
		display: flex !important;
		width: 29px !important;
		height: 25px !important;
		flex-direction: column !important;
		justify-content: space-between !important;
		padding: 2px 0 !important;
		cursor: pointer !important;
		z-index: 9100 !important;
	}

	.tm-hamburger span {
		display: block !important;
		width: 29px !important;
		height: 2.2px !important;
		background: #000000 !important;
		border-radius: 5px !important;
	}

	.tm-mobile-search-button {
		display: flex !important;
		align-items: center !important;
		justify-content: center !important;
		width: 28px !important;
		height: 28px !important;
		padding: 0 !important;
		margin: 0 !important;
		background: transparent !important;
		border: 0 !important;
		color: #000000 !important;
		cursor: pointer !important;
	}

	.tm-header-left .tm-mobile-search-button {
		margin-left: 18px !important;
	}

	.tm-header-right {
		display: flex !important;
		width: auto !important;
		margin-left: auto !important;
		z-index: 40 !important;
	}

	.tm-desktop-account {
		display: none !important;
	}

	.tm-mobile-account {
		display: inline-flex !important;
		position: relative !important;
		width: 34px !important;
		height: 34px !important;
		flex: 0 0 34px !important;
		margin-right: 8px !important;
		z-index: 100005 !important;
	}

	.tm-mobile-account .tm-account-toggle {
		display: inline-flex !important;
		width: 34px !important;
		height: 34px !important;
	}

	.tm-mobile-account .tm-account-icon {
		width: 29px !important;
		height: 29px !important;
	}

	.tm-mobile-account .tm-account-menu {
		top: calc(100% + 10px) !important;
		left: auto !important;
		right: -8px !important;
		transform: translateY(-5px) !important;
		width: 180px !important;
	}

	.tm-mobile-account.is-open .tm-account-menu {
		transform: translateY(0) !important;
	}

	.tm-mobile-cart {
		position: relative !important;
		display: flex !important;
		align-items: center !important;
		justify-content: center !important;
		width: 34px !important;
		height: 34px !important;
		color: #000000 !important;
	}

	.tm-mobile-cart svg {
		display: block !important;
		width: 27px !important;
		height: 27px !important;
	}

	.tm-nav-toggle {
		position: absolute !important;
		width: 1px !important;
		height: 1px !important;
		overflow: hidden !important;
		clip: rect(0, 0, 0, 0) !important;
	}

	/* OUTSIDE TAP/CLICK BACKDROP FIX */
	.tm-nav-backdrop {
		position: fixed !important;
		inset: 0 !important;
		display: block !important;
		background: rgba(0, 0, 0, 0.48) !important;
		backdrop-filter: blur(2px) !important;
		opacity: 0 !important;
		visibility: hidden !important;
		pointer-events: none !important;
		z-index: 99990 !important;
		cursor: pointer !important;
		transition: opacity 0.3s ease, visibility 0.3s ease !important;
	}

	.tm-mobile-drawer {
		position: fixed !important;
		top: 0 !important;
		left: 0 !important;
		bottom: 0 !important;
		width: min(82vw, 415px) !important;
		height: 100dvh !important;
		display: block !important;
		padding: 112px 28px 35px 32px !important;
		background: #ffffff !important;
		transform: translate3d(-105%, 0, 0) !important;
		visibility: hidden !important;
		pointer-events: none !important;
		z-index: 100000 !important;
		overflow-y: auto !important;
		box-shadow: 8px 0 35px rgba(0,0,0,0.14) !important;
		transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), visibility 0.35s ease !important;
	}

	#tm-nav-toggle:checked ~ .tm-mobile-drawer {
		transform: translate3d(0, 0, 0) !important;
		visibility: visible !important;
		pointer-events: auto !important;
	}

	#tm-nav-toggle:checked ~ .tm-nav-backdrop {
		opacity: 1 !important;
		visibility: visible !important;
		pointer-events: auto !important;
	}

	.tm-mobile-close-btn {
		position: absolute !important;
		top: 27px !important;
		right: 25px !important;
		width: 52px !important;
		height: 52px !important;
		display: flex !important;
		align-items: center !important;
		justify-content: center !important;
		background: #f8f8f8 !important;
		border: 1px solid #eeeeee !important;
		border-radius: 50% !important;
		color: #000000 !important;
		cursor: pointer !important;
		z-index: 100001 !important;
	}

	.tm-mobile-menu {
		display: flex !important;
		flex-direction: column !important;
		width: 100% !important;
		margin: 0 !important;
		padding: 0 !important;
		list-style: none !important;
	}

	.tm-mobile-menu > li > a,
	.tm-mobile-shop-toggle {
		width: 100% !important;
		min-height: 68px !important;
		display: flex !important;
		align-items: center !important;
		justify-content: space-between !important;
		padding: 0 !important;
		background: transparent !important;
		border: 0 !important;
		border-bottom: 1px solid #e9e9e9 !important;
		color: #000000 !important;
		font-size: 23px !important;
		font-weight: 700 !important;
		cursor: pointer !important;
	}

	.tm-mobile-shop-panel {
		display: none !important;
		padding: 7px 0 7px 18px !important;
		border-bottom: 1px solid #e9e9e9 !important;
	}

	.tm-mobile-shop.is-open > .tm-mobile-shop-panel {
		display: block !important;
	}

	.tm-mobile-shop-panel > a {
		display: flex !important;
		align-items: center !important;
		min-height: 49px !important;
		color: #333333 !important;
		font-size: 17px !important;
		font-weight: 600 !important;
	}

	.tm-mobile-submenu-toggle {
		width: 100% !important;
		min-height: 49px !important;
		display: flex !important;
		align-items: center !important;
		justify-content: space-between !important;
		background: transparent !important;
		border: 0 !important;
		color: #333333 !important;
		font-size: 16px !important;
		font-weight: 600 !important;
		cursor: pointer !important;
	}

	.tm-mobile-submenu-content {
		display: none !important;
		padding: 0 0 7px 16px !important;
	}

	.tm-mobile-submenu.is-open .tm-mobile-submenu-content {
		display: block !important;
	}

	.tm-mobile-submenu-content a {
		display: flex !important;
		align-items: center !important;
		min-height: 43px !important;
		color: #666666 !important;
		font-size: 15px !important;
		font-weight: 500 !important;
	}

	.tm-mobile-contact {
		padding-top: 15px !important;
	}

	.tm-mobile-contact a {
		min-height: 61px !important;
		justify-content: center !important;
		background: #000000 !important;
		color: #ffffff !important;
		border-radius: 999px !important;
		font-size: 18px !important;
		font-weight: 700 !important;
	}

	.tm-mobile-search-panel {
		position: fixed !important;
		inset: 0 !important;
		display: block !important;
		width: 100% !important;
		height: 100dvh !important;
		padding: 28px 20px !important;
		background: #ffffff !important;
		z-index: 110000 !important;
		opacity: 0 !important;
		visibility: hidden !important;
		pointer-events: none !important;
		transform: translateY(-12px) !important;
		transition: opacity 0.25s ease, visibility 0.25s ease, transform 0.25s ease !important;
		overflow-y: auto !important;
	}

	.tm-mobile-search-panel.is-open {
		opacity: 1 !important;
		visibility: visible !important;
		pointer-events: auto !important;
		transform: translateY(0) !important;
	}

	.tm-mobile-search-header {
		display: flex !important;
		align-items: center !important;
		gap: 18px !important;
		margin-bottom: 35px !important;
		font-size: 24px !important;
		font-weight: 700 !important;
	}

	.tm-mobile-search-close {
		width: 44px !important;
		height: 44px !important;
		display: flex !important;
		align-items: center !important;
		justify-content: center !important;
		background: #f5f5f7 !important;
		border: 0 !important;
		border-radius: 50% !important;
		cursor: pointer !important;
	}

	.tm-mobile-search-form {
		display: flex !important;
		flex-direction: column !important;
		gap: 13px !important;
	}

	.tm-mobile-search-input-wrap {
		height: 58px !important;
		display: flex !important;
		align-items: center !important;
		gap: 12px !important;
		padding: 0 17px !important;
		background: #f5f5f7 !important;
		border-radius: 999px !important;
	}

	#tm-mobile-search-input {
		width: 100% !important;
		height: 100% !important;
		background: transparent !important;
		border: 0 !important;
		outline: 0 !important;
		font-size: 17px !important;
	}

	.tm-mobile-search-form > button {
		height: 55px !important;
		background: #000000 !important;
		border: 0 !important;
		border-radius: 999px !important;
		color: #ffffff !important;
		font-size: 17px !important;
		font-weight: 700 !important;
		cursor: pointer !important;
	}
}

/* =========================================================
   BODY LOCK
   ========================================================= */
body.tm-mobile-menu-open,
body.tm-mobile-search-open {
	overflow: hidden !important;
}
</style>

<style id="tm-mobile-zoom-safety-fix">
/* MOBILE ZOOM-OUT / HORIZONTAL OVERFLOW SAFETY FIX
 * Keeps the existing mobile header layout active on real mobile devices
 * even when pinch-zoom changes the CSS viewport width. */
@media screen and (max-device-width: 1100px) {
	html, body {
		max-width: 100% !important;
		overflow-x: clip !important;
	}

	#tm-site-header, #tm-site-header .tm-header-inner {
		width: 100% !important;
		max-width: 100% !important;
		min-width: 0 !important;
	}
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
	'use strict';

	/* =====================================================
	   MOBILE MENU & OVERLAY BACKDROP HANDLER
	   ===================================================== */
	const navToggle = document.getElementById('tm-nav-toggle');
	const mobileDrawer = document.getElementById('tm-mobile-drawer');
	const backdrop = document.querySelector('.tm-nav-backdrop');

	function openMobileMenu() {
		if (!navToggle) return;
		navToggle.checked = true;
		document.body.classList.add('tm-mobile-menu-open');
		if (mobileDrawer) {
			mobileDrawer.setAttribute('aria-hidden', 'false');
		}
	}

	function closeMobileMenu() {
		if (!navToggle) return;
		navToggle.checked = false;
		document.body.classList.remove('tm-mobile-menu-open');
		if (mobileDrawer) {
			mobileDrawer.setAttribute('aria-hidden', 'true');
		}
	}

	if (navToggle) {
		navToggle.addEventListener('change', function () {
			if (this.checked) {
				openMobileMenu();
			} else {
				closeMobileMenu();
			}
		});
	}

	/* TAP / CLICK OUTSIDE SIDEBAR DRAWER TO CLOSE */
	if (backdrop) {
		backdrop.addEventListener('click', function (event) {
			event.preventDefault();
			event.stopPropagation();
			closeMobileMenu();
		});
		backdrop.addEventListener('touchstart', function (event) {
			event.preventDefault();
			closeMobileMenu();
		}, { passive: false });
	}

	/* =====================================================
	   ACCOUNT MENU — DESKTOP + MOBILE
	   ===================================================== */
	const accountToggles = document.querySelectorAll('.tm-account-toggle');
	const accountWraps = document.querySelectorAll('.tm-account-wrap');

	function closeAccountMenus() {
		accountWraps.forEach(function (wrap) {
			wrap.classList.remove('is-open');
			const toggle = wrap.querySelector('.tm-account-toggle');
			if (toggle) toggle.setAttribute('aria-expanded', 'false');
		});
	}

	accountToggles.forEach(function (toggle) {
		toggle.addEventListener('click', function (event) {
			event.preventDefault();
			event.stopPropagation();
			const wrap = this.closest('.tm-account-wrap');
			if (!wrap) return;

			const wasOpen = wrap.classList.contains('is-open');
			closeAccountMenus();

			if (!wasOpen) {
				wrap.classList.add('is-open');
				this.setAttribute('aria-expanded', 'true');
			}
		});
	});

	accountWraps.forEach(function (wrap) {
		wrap.querySelectorAll('.tm-account-menu a').forEach(function (link) {
			link.addEventListener('click', function () {
				closeAccountMenus();
			});
		});
	});

	/* =====================================================
	   DESKTOP SHOP DROPDOWN
	   ===================================================== */
	const shopToggle = document.querySelector('.tm-shop-toggle');
	const shopDropdown = document.querySelector('.tm-shop-dropdown');

	if (shopToggle && shopDropdown) {
		shopToggle.addEventListener('click', function (event) {
			event.preventDefault();
			event.stopPropagation();
			const isOpen = shopDropdown.classList.toggle('is-open');
			shopToggle.setAttribute(
				'aria-expanded',
				isOpen ? 'true' : 'false'
			);
		});
	}

	/* =====================================================
	   DESKTOP SUBMENUS
	   ===================================================== */
	const desktopSubmenuButtons = document.querySelectorAll(
		'.tm-primary-navigation .tm-submenu-header'
	);

	desktopSubmenuButtons.forEach(function (button) {
		button.addEventListener('click', function (event) {
			event.preventDefault();
			event.stopPropagation();
			const parent = this.closest('.tm-submenu');
			if (!parent) return;

			const siblings = parent.parentElement.querySelectorAll(
				'.tm-submenu'
			);
			siblings.forEach(function (item) {
				if (item !== parent) {
					item.classList.remove('is-open');
					const siblingButton = item.querySelector(
						'.tm-submenu-header'
					);
					if (siblingButton) {
						siblingButton.setAttribute(
							'aria-expanded',
							'false'
						);
					}
				}
			});

			const open = parent.classList.toggle('is-open');
			button.setAttribute(
				'aria-expanded',
				open ? 'true' : 'false'
			);
		});
	});

	/* =====================================================
	   MOBILE SHOP
	   ===================================================== */
	const mobileShop = document.querySelector('.tm-mobile-shop');
	const mobileShopToggle = document.querySelector('.tm-mobile-shop-toggle');

	if (mobileShopToggle && mobileShop) {
		mobileShopToggle.addEventListener(
			'click',
			function (event) {
				event.preventDefault();
				event.stopPropagation();
				const isOpen = mobileShop.classList.toggle('is-open');
				mobileShopToggle.setAttribute(
					'aria-expanded',
					isOpen ? 'true' : 'false'
				);
			}
		);
	}

	/* =====================================================
	   MOBILE SUBMENUS
	   ===================================================== */
	const mobileSubmenuButtons = document.querySelectorAll(
		'.tm-mobile-submenu-toggle'
	);

	mobileSubmenuButtons.forEach(function (button) {
		button.addEventListener('click', function (event) {
			event.preventDefault();
			event.stopPropagation();
			const parent = this.closest('.tm-mobile-submenu');
			if (!parent) return;

			const open = parent.classList.toggle('is-open');
			this.setAttribute(
				'aria-expanded',
				open ? 'true' : 'false'
			);
		});
	});

	/* =====================================================
	   MOBILE NORMAL LINKS
	   ===================================================== */
	const mobileNormalLinks = document.querySelectorAll(
		'.tm-mobile-menu a'
	);

	mobileNormalLinks.forEach(function (link) {
		link.addEventListener('click', function () {
			closeMobileMenu();
		});
	});

	/* =====================================================
	   ESCAPE KEY
	   ===================================================== */
	document.addEventListener('keydown', function (event) {
		if (event.key !== 'Escape') return;

		closeMobileMenu();
		closeMobileSearch();
		closeAccountMenus();
		if (shopDropdown) {
			shopDropdown.classList.remove( 'is-open' );
		}
		const desktopResults = document.getElementById('tm-desktop-search-results');
		if (desktopResults) {
			desktopResults.classList.remove('is-active');
		}
	});

	/* =====================================================
	   CLOSE DESKTOP DROPDOWN & SEARCH RESULTS OUTSIDE
	   ===================================================== */
	document.addEventListener('click', function (event) {
		if (!event.target.closest('.tm-account-wrap')) {
			closeAccountMenus();
		}

		if ( shopDropdown && !event.target.closest('.tm-shop-dropdown') ) {
			shopDropdown.classList.remove( 'is-open' );
			if (shopToggle) {
				shopToggle.setAttribute(
					'aria-expanded',
					'false'
				);
			}
			document
				.querySelectorAll('.tm-submenu.is-open')
				.forEach(function (submenu) {
					submenu.classList.remove( 'is-open' );
				});
		}

		const desktopSearchWrap = document.querySelector('.tm-desktop-search-wrap');
		const desktopResults = document.getElementById('tm-desktop-search-results');
		if (desktopSearchWrap && desktopResults && !desktopSearchWrap.contains(event.target)) {
			desktopResults.classList.remove('is-active');
		}
	});

	/* =====================================================
	   MOBILE SEARCH PANEL
	   ===================================================== */
	const mobileSearchOpen = document.getElementById( 'tm-mobile-search-open' );
	const mobileSearchClose = document.getElementById( 'tm-mobile-search-close' );
	const mobileSearchPanel = document.getElementById( 'tm-mobile-search-panel' );
	const mobileSearchForm = document.getElementById( 'tm-mobile-search-form' );
	const mobileSearchInput = document.getElementById( 'tm-mobile-search-input' );

	function openMobileSearch() {
		closeMobileMenu();
		if (!mobileSearchPanel) return;
		mobileSearchPanel.classList.add( 'is-open' );
		mobileSearchPanel.setAttribute( 'aria-hidden', 'false' );
		document.body.classList.add( 'tm-mobile-search-open' );
		setTimeout(function () {
			if (mobileSearchInput) {
				mobileSearchInput.focus();
			}
		}, 250);
	}

	function closeMobileSearch() {
		if (!mobileSearchPanel) return;
		mobileSearchPanel.classList.remove( 'is-open' );
		mobileSearchPanel.setAttribute( 'aria-hidden', 'true' );
		document.body.classList.remove( 'tm-mobile-search-open' );
	}

	if (mobileSearchOpen) {
		mobileSearchOpen.addEventListener( 'click', openMobileSearch );
	}

	if (mobileSearchClose) {
		mobileSearchClose.addEventListener( 'click', closeMobileSearch );
	}

	/* =====================================================
	   THIRSTY MOLECULE CUSTOM REAL-TIME SEARCH ENGINE
	   Searches products, product types, skincare, benefits,
	   concerns, synonyms and site pages — not only product names.
	   Product results always use the site's custom page URLs.
	   ===================================================== */

	function escapeHTML(value) {
		return String(value)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	/*
	 * Customer-language search index.
	 * A visitor does NOT need to know a product's exact name.
	 */
	const TM_SEARCH_INDEX = [
		{
			type: 'product',
			name: 'CetaGlow — Gentle Cream Cleanser',
			url: <?php echo wp_json_encode( home_url( '/ceta-glow/' ) ); ?>,
			keywords: [
				'cetaglow', 'ceta glow', 'cleanser', 'face wash', 'non foaming', 'gentle', 'sensitive', 'dry skin'
			],
			meta: 'Cleanser • Skincare'
		},
		{
			type: 'product',
			name: 'HydraMatrix — Gel-Cream Moisturizer',
			url: <?php echo wp_json_encode( home_url( '/molecule-hydramatrix-gel-cream-moisturizer-product-page/' ) ); ?>,
			keywords: [
				'hydramatrix', 'hydra matrix', 'moisturiser', 'moisturizer', 'cream', 'face cream', 'gel cream', 'ceramide', 'pentavitin', 'hyaluronic acid'
			],
			meta: 'Moisturizer • Skincare'
		},
		{
			type: 'product',
			name: 'Auri',
			url: <?php echo wp_json_encode( home_url( '/aurii/' ) ); ?>,
			keywords: [ 'auri', 'aurii' ],
			meta: 'Skincare product'
		},
		{
			type: 'product',
			name: 'Immoria',
			url: <?php echo wp_json_encode( home_url( '/immoriaa/' ) ); ?>,
			keywords: [ 'immoria', 'immoriaa' ],
			meta: 'Skincare product'
		},
		{
			type: 'page',
			name: 'Skincare',
			url: <?php echo wp_json_encode( home_url( '/skincare/' ) ); ?>,
			keywords: [ 'skincare', 'skin care', 'skin', 'skin products', 'skin care products' ],
			meta: 'Explore skincare'
		},
		{
			type: 'page',
			name: 'Shop All',
			url: <?php echo wp_json_encode( home_url( '/shop-all/' ) ); ?>,
			keywords: [ 'shop all', 'all products', 'products', 'product range', 'shop products' ],
			meta: 'All products'
		},
		{
			type: 'page',
			name: 'Bestsellers',
			url: <?php echo wp_json_encode( home_url( '/bestsellers/' ) ); ?>,
			keywords: [ 'bestseller', 'bestsellers', 'best seller', 'best sellers', 'popular products', 'top products' ],
			meta: 'Best-selling products'
		},
		{
			type: 'category',
			name: 'Cleansers',
			url: <?php echo wp_json_encode( home_url( '/cleansers/' ) ); ?>,
			keywords: [ 'cleanser category', 'cleanser page', 'cleansers category', 'face cleansers', 'cleanser products', 'cleansing products' ],
			meta: 'Shop cleansers'
		},
		{
			type: 'category',
			name: 'Moisturizers',
			url: <?php echo wp_json_encode( home_url( '/moisturizers/' ) ); ?>,
			keywords: [ 'moisturizer category', 'moisturizer page', 'moisturizers category', 'face moisturizers', 'moisturiser category', 'moisturising products' ],
			meta: 'Shop moisturizers'
		},
		/* Future concern pages — indexed now so they work when published. */
		{
			type: 'concern',
			name: 'Dark Spots & Pigmentation',
			url: <?php echo wp_json_encode( home_url( '/concern/dark-spots-pigmentation/' ) ); ?>,
			keywords: [ 'dark spots', 'dark spot', 'pigmentation', 'pigmented skin', 'uneven skin tone', 'uneven tone', 'spots' ],
			meta: 'Skin concern'
		},
		{
			type: 'concern',
			name: 'Dry & Dehydrated Skin',
			url: <?php echo wp_json_encode( home_url( '/concern/dry-dehydrated-skin/' ) ); ?>,
			keywords: [ 'dry skin', 'dehydrated skin', 'dry dehydrated skin', 'dehydration', 'skin dryness', 'dry face' ],
			meta: 'Skin concern'
		},
		{
			type: 'concern',
			name: 'Sensitive Skin',
			url: <?php echo wp_json_encode( home_url( '/concern/sensitive-skin/' ) ); ?>,
			keywords: [ 'sensitive skin', 'sensitivity', 'sensitive face', 'easily irritated skin', 'irritated skin' ],
			meta: 'Skin concern'
		},
		{
			type: 'concern',
			name: 'Anti-Ageing',
			url: <?php echo wp_json_encode( home_url( '/concern/anti-ageing/' ) ); ?>,
			keywords: [ 'anti ageing', 'anti-aging', 'anti aging', 'ageing', 'aging', 'fine lines', 'mature skin' ],
			meta: 'Skin concern'
		},
		{
			type: 'concern',
			name: 'Oily & Acne-Prone Skin',
			url: <?php echo wp_json_encode( home_url( '/concern/oily-acne-prone-skin/' ) ); ?>,
			keywords: [ 'oily skin', 'oily', 'acne prone skin', 'acne-prone', 'acne', 'breakouts', 'blemishes', 'excess oil' ],
			meta: 'Skin concern'
		}
	];

	function normalizeSearchText(value) {
		return String(value || '')
			.toLowerCase()
			.normalize('NFD')
			.replace(/[\u0300-\u036f]/g, '')
			.replace(/[^a-z0-9]+/g, ' ')
			.trim();
	}

	function searchTokens(value) {
		return normalizeSearchText(value).split(/\s+/).filter(Boolean);
	}

	function scoreSearchItem(item, query) {
		const q = normalizeSearchText(query);
		const qTokens = searchTokens(query);
		if (!q || !qTokens.length) return 0;

		const name = normalizeSearchText(item.name);
		const fields = [name].concat((item.keywords || []).map(normalizeSearchText));
		let score = 0;

		/*
		 * STRICT MATCHING:
		 * Every typed word must match this item's name or one of
		 * this item's own keywords. This prevents unrelated products
		 * from appearing just because they share one generic word.
		 */
		const allTokensMatch = qTokens.every(function (token) {
			return fields.some(function (field) {
				return field.split(' ').some(function (word) {
					return word === token || word.startsWith(token);
				});
			});
		});

		if (!allTokensMatch) return 0;

		/* Exact multi-word phrase gets the strongest relevance. */
		if (name === q) score += 3000;
		else if (name.startsWith(q)) score += 2200;
		else if (name.includes(q)) score += 1800;

		(item.keywords || []).forEach(function (keyword) {
			const k = normalizeSearchText(keyword);

			if (k === q) score += 2000;
			else if (k.startsWith(q)) score += 1500;
			else if (k.includes(q)) score += 1200;
		});

		/* Reward every token that matches the product's own fields. */
		qTokens.forEach(function (token) {
			fields.forEach(function (field) {
				const words = field.split(' ');

				if (words.some(function (word) { return word === token; })) {
					score += 400;
				} else if (words.some(function (word) { return word.startsWith(token); })) {
					score += 250;
				}
			});
		});

		/* Products remain preferred over generic pages/categories. */
		if (item.type === 'product') score += 100;

		return score;
	}

	function filterProducts(query) {
		const cleanQuery = normalizeSearchText(query);
		if (!cleanQuery) return [];

		return TM_SEARCH_INDEX
			.map(function (item, index) {
				return {
					item: item,
					score: scoreSearchItem(item, cleanQuery),
					index: index
				};
			})
			.filter(function (entry) {
				return entry.score > 0;
			})
			.sort(function (a, b) {
				return b.score - a.score || a.index - b.index;
			})
			.slice(0, 8)
			.map(function (entry) {
				return entry.item;
			});
	}

	/* =====================================================
	   OPEN THE BEST MATCH FROM SEARCH SUBMIT / KEYBOARD
	   ===================================================== */
	function openBestSearchMatch(query) {
		const matches = filterProducts(query);

		if (matches.length > 0 && matches[0].url) {
			window.location.href = matches[0].url;
			return true;
		}

		return false;
	}

	/* =====================================================
	   DESKTOP LIVE SEARCH HANDLER
	   ===================================================== */
	const desktopInput = document.querySelector('.tm-desktop-search-input');
	const desktopResults = document.getElementById('tm-desktop-search-results');
	let desktopTimer = null;

	const desktopSearchForm = document.querySelector('.tm-desktop-search');

	if (desktopSearchForm && desktopInput) {
		desktopSearchForm.addEventListener('submit', function (event) {
			event.preventDefault();
			openBestSearchMatch(desktopInput.value.trim());
		});
	}

	if (desktopInput && desktopResults) {
		desktopInput.addEventListener('input', function () {
			clearTimeout(desktopTimer);
			const val = this.value.trim();

			if (!val) {
				desktopResults.innerHTML = '';
				desktopResults.classList.remove('is-active');
				return;
			}

			desktopTimer = setTimeout(function () {
				const matches = filterProducts(val);

				desktopResults.innerHTML = '';

				if (matches.length === 0) {
					desktopResults.innerHTML = '<div class="tm-search-no-results">No products found.</div>';
				} else {
					matches.forEach(prod => {
						const a = document.createElement('a');
						a.className = 'tm-search-result-item';
						a.href = prod.url;

						let imgHTML = '';
						if (prod.image) {
							imgHTML = '<img class="tm-search-result-image" src="' + escapeHTML(prod.image) + '" alt="">';
						}
						a.innerHTML = imgHTML + '<span>' + escapeHTML(prod.name) + (prod.meta ? '<small style="display:block;font-size:11px;font-weight:500;color:#777;margin-top:3px;">' + escapeHTML(prod.meta) + '</small>' : '') + '</span>';
						desktopResults.appendChild(a);
					});
				}

				desktopResults.classList.add('is-active');
			}, 200);
		});

		desktopInput.addEventListener('focus', function () {
			if (this.value.trim() && desktopResults.children.length > 0) {
				desktopResults.classList.add('is-active');
			}
		});
	}

	/* =====================================================
	   MOBILE LIVE SEARCH HANDLER
	   ===================================================== */
	const mobileSearchResults = document.getElementById('tm-mobile-search-results');
	const mobileSearchStatus = document.getElementById('tm-mobile-search-status');
	let mobileTimer = null;

	if (mobileSearchForm && mobileSearchInput) {
		mobileSearchForm.addEventListener('submit', function (event) {
			event.preventDefault();
			openBestSearchMatch(mobileSearchInput.value.trim());
		});
	}

	if (mobileSearchInput && mobileSearchResults && mobileSearchStatus) {
		mobileSearchInput.addEventListener('input', function () {
			clearTimeout(mobileTimer);
			const val = this.value.trim();

			if (!val) {
				mobileSearchResults.innerHTML = '';
				mobileSearchStatus.textContent = '';
				return;
			}

			mobileSearchStatus.textContent = 'Searching...';

			mobileTimer = setTimeout(function () {
				const matches = filterProducts(val);

				mobileSearchResults.innerHTML = '';

				if (matches.length === 0) {
					mobileSearchStatus.textContent = 'No products found.';
				} else {
					mobileSearchStatus.textContent = matches.length + (matches.length === 1 ? ' product found' : ' products found');
					matches.forEach(prod => {
						const a = document.createElement('a');
						a.className = 'tm-search-result-item';
						a.style.display = 'flex';
						a.style.alignItems = 'center';
						a.style.gap = '12px';
						a.style.padding = '12px 0';
						a.style.borderBottom = '1px solid #eeeeee';
						a.style.textDecoration = 'none';
						a.style.color = '#000000';
						a.style.fontWeight = '600';
						a.href = prod.url;

						let imgHTML = '';
						if (prod.image) {
							imgHTML = '<img class="tm-search-result-image" src="' + escapeHTML(prod.image) + '" alt="">';
						}
						a.innerHTML = imgHTML + '<span>' + escapeHTML(prod.name) + (prod.meta ? '<small style="display:block;font-size:11px;font-weight:500;color:#777;margin-top:3px;">' + escapeHTML(prod.meta) + '</small>' : '') + '</span>';
						mobileSearchResults.appendChild(a);
					});
				}
			}, 200);
		});
	}
});
</script>

<!-- =====================================================
     LIVE WOOCOMMERCE CART COUNT SYNC
     Keeps desktop + mobile header badges equal to the real cart.
     ===================================================== -->
<script>
(function () {
	'use strict';

	const cartApiUrl = <?php echo wp_json_encode( home_url( '/wp-json/wc/store/v1/cart' ) ); ?>;
	const cartAjaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;

	function getCartCountElements() {
		return document.querySelectorAll(
			'[data-tm-cart-count], .tm-cart-count, .tm-header-cart-count'
		);
	}

	function setCartCount(count) {
		let value = parseInt(count, 10);
		if (!Number.isFinite(value) || value < 0) value = 0;

		getCartCountElements().forEach(function (element) {
			element.textContent = String(value);
			element.setAttribute('aria-label', value + ' items in cart');
		});
	}

	function extractCartCount(data) {
		if (!data) return 0;

		if (data.items_count !== undefined && data.items_count !== null) {
			return parseInt(data.items_count, 10) || 0;
		}

		if (data.count !== undefined && data.count !== null) {
			return parseInt(data.count, 10) || 0;
		}

		if (Array.isArray(data.items)) {
			return data.items.reduce(function (total, item) {
				return total + (parseInt(item.quantity, 10) || 0);
			}, 0);
		}

		if (data.data) return extractCartCount(data.data);

		return 0;
	}

	async function syncCartCount() {
		try {
			const response = await fetch(
				cartApiUrl +
				(cartApiUrl.indexOf('?') === -1 ? '?' : '&') +
				'_tm_cart=' + Date.now(),
				{
					method: 'GET',
					credentials: 'same-origin',
					cache: 'no-store',
					headers: {
						'Accept': 'application/json'
					}
				}
			);

			if (!response.ok) throw new Error('Store API unavailable');

			const data = await response.json();

			/* This is the authoritative WooCommerce cart quantity. */
			setCartCount(extractCartCount(data));
			return;

		} catch (error) {
			/* Fall back to the existing live-cart AJAX endpoint if available. */
		}

		try {
			const body = new URLSearchParams();

			body.set('action', 'tm_live_cart');
			body.set('_tm_cart', String(Date.now()));

			const response = await fetch(cartAjaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				cache: 'no-store',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'Accept': 'application/json'
				},
				body: body.toString()
			});

			if (!response.ok) return;

			const data = await response.json();

			setCartCount(extractCartCount(data));

		} catch (error) {
			/* Keep the server-rendered value if both live sources are unavailable. */
		}
	}

	function requestCartSync() {
		window.clearTimeout(window.tmCartSyncTimer);

		window.tmCartSyncTimer = window.setTimeout(
			syncCartCount,
			60
		);
	}

	/* Initial real cart count. */
	if (document.readyState === 'loading') {
		document.addEventListener(
			'DOMContentLoaded',
			syncCartCount,
			{ once: true }
		);
	} else {
		syncCartCount();
	}

	/* Re-check when returning to the page. */
	window.addEventListener(
		'pageshow',
		requestCartSync
	);

	window.addEventListener(
		'focus',
		requestCartSync
	);

	document.addEventListener(
		'visibilitychange',
		function () {
			if (!document.hidden) {
				requestCartSync();
			}
		}
	);

	/* WooCommerce + existing custom cart events. */
	[
		'tm_cart_updated',
		'tm_cart_refresh',
		'added_to_cart',
		'removed_from_cart',
		'updated_wc_div',
		'wc_fragments_refreshed',
		'wc_fragments_loaded'
	].forEach(function (eventName) {
		document.addEventListener(
			eventName,
			requestCartSync
		);
	});

	/* jQuery/WooCommerce events, when jQuery exists. */
	if (window.jQuery) {
		window.jQuery(document.body).on(
			'added_to_cart removed_from_cart updated_wc_div wc_fragments_refreshed wc_fragments_loaded tm_cart_updated tm_cart_refresh',
			requestCartSync
		);
	}

	/*
	 * Your product pages are hard-coded and may not dispatch an event.
	 * This keeps the badge synchronized with the real WooCommerce cart.
	 */
	window.setInterval(function () {
		if (!document.hidden) {
			syncCartCount();
		}
	}, 2000);

	/*
	 * Existing custom Add to Cart code can call this immediately
	 * after successfully changing the WooCommerce cart.
	 */
	window.TMSyncHeaderCartCount = syncCartCount;

})();
</script>

<main id="content">
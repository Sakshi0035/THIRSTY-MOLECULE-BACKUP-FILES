/**
 * Thirsty Molecule - front-end interactions (vanilla JS, no dependencies).
 * Replaces the React state/effect logic of the original prototype:
 *  - mobile navigation toggle
 *  - hero carousel: auto rotation (1500ms), arrows, dots, touch swipe
 */
(function () {
	'use strict';

	function initMenu() {
		var toggle = document.querySelector('.nav-shell .menu');
		var nav = document.querySelector('.nav-shell nav');
		if (!toggle || !nav) {
			return;
		}
		toggle.setAttribute('aria-expanded', 'false');
		toggle.addEventListener('click', function () {
			var open = nav.classList.toggle('open');
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
		nav.addEventListener('click', function (event) {
			if (event.target.tagName === 'A') {
				nav.classList.remove('open');
				toggle.setAttribute('aria-expanded', 'false');
			}
		});
	}

	function initHero() {
		var hero = document.querySelector('[data-tm-carousel]');
		if (!hero) {
			return;
		}

		var data = [];
		try {
			data = JSON.parse(hero.getAttribute('data-slides') || '[]');
		} catch (e) {
			data = [];
		}
		if (data.length < 1) {
			return;
		}

		var eyebrow = hero.querySelector('.eyebrow');
		var title = hero.querySelector('h1');
		var text = hero.querySelector('.hero-text');
		var primary = hero.querySelector('.hero-actions a:nth-child(1)');
		var secondary = hero.querySelector('.hero-actions a:nth-child(2)');
		var productWrap = hero.querySelector('.hero-product');
		var productImg = productWrap ? productWrap.querySelector('img') : null;
		var dots = Array.prototype.slice.call(hero.querySelectorAll('.dots button'));
		var active = 0;
		var timer = null;
		var startX = null;

		function render(index) {
			var slide = data[index];
			hero.className = 'hero ' + slide.id;
			hero.setAttribute('data-tm-carousel', '');
			if (eyebrow) { eyebrow.textContent = slide.ritual; }
			if (title) { title.textContent = slide.title; }
			if (text) { text.textContent = slide.text; }
			if (primary) { primary.textContent = slide.primary; primary.setAttribute('href', slide.primary_url); }
			if (secondary) { secondary.textContent = slide.secondary || ''; secondary.setAttribute('href', slide.secondary_url); secondary.style.display = slide.secondary ? '' : 'none'; }
			if (productWrap) {
				if (slide.show_product && slide.image) {
					productWrap.hidden = false;
					productWrap.style.display = '';
					if (productImg) {
						productImg.setAttribute('src', slide.image);
						productImg.setAttribute('alt', slide.id + ' product');
						/* restart the arrive animation */
						productImg.style.animation = 'none';
						void productImg.offsetWidth;
						productImg.style.animation = '';
					}
				} else {
					productWrap.hidden = true;
					productWrap.style.display = 'none';
				}
			}
			dots.forEach(function (dot, i) {
				dot.className = i === index ? 'active' : '';
				dot.setAttribute('aria-current', i === index ? 'true' : 'false');
			});
			active = index;
		}

		function move(step) {
			render((active + step + data.length) % data.length);
		}

		function start() {
			stop();
			if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
				return;
			}
			timer = window.setInterval(function () { move(1); }, 1500);
		}

		function stop() {
			if (timer) {
				window.clearInterval(timer);
				timer = null;
			}
		}

		var prev = hero.querySelector('.arrow.prev');
		var next = hero.querySelector('.arrow.next');
		if (prev) { prev.addEventListener('click', function () { move(-1); start(); }); }
		if (next) { next.addEventListener('click', function () { move(1); start(); }); }
		dots.forEach(function (dot, i) {
			dot.addEventListener('click', function () { render(i); start(); });
		});

		hero.addEventListener('touchstart', function (event) {
			startX = event.touches[0].clientX;
		}, { passive: true });

		hero.addEventListener('touchend', function (event) {
			if (startX !== null) {
				var endX = event.changedTouches[0].clientX;
				if (Math.abs(endX - startX) > 45) {
					move(endX < startX ? 1 : -1);
					start();
				}
			}
			startX = null;
		}, { passive: true });

		hero.addEventListener('mouseenter', stop);
		hero.addEventListener('mouseleave', start);
		document.addEventListener('visibilitychange', function () {
			if (document.hidden) { stop(); } else { start(); }
		});

		render(0);
		start();
	}

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
		} else {
			document.addEventListener('DOMContentLoaded', fn);
		}
	}

	ready(function () {
		initMenu();
		initHero();
	});
})();
/* =========================================================
   THIRSTY MOLECULE - SHOP DROPDOWN
   ========================================================= */

document.addEventListener('DOMContentLoaded', function () {

    /* SHOP MENU */
    const shopMenu = document.querySelector('.tm-shop-menu');
    const shopToggle = document.querySelector('.tm-shop-toggle');

    if (shopMenu && shopToggle) {

        shopToggle.addEventListener('click', function (event) {

            event.preventDefault();
            event.stopPropagation();

            shopMenu.classList.toggle('tm-shop-open');

        });

    }


    /* SHOP SUBMENUS */
    const submenuToggles = document.querySelectorAll('.tm-submenu-toggle');

    submenuToggles.forEach(function (toggle) {

        toggle.addEventListener('click', function (event) {

            event.preventDefault();
            event.stopPropagation();

            const submenu = toggle.closest('.tm-submenu');

            if (!submenu) {
                return;
            }

            /* Close other submenus */
            document.querySelectorAll('.tm-submenu.tm-submenu-open').forEach(function (other) {

                if (other !== submenu) {
                    other.classList.remove('tm-submenu-open');
                }

            });

            /* Open / close clicked submenu */
            submenu.classList.toggle('tm-submenu-open');

        });

    });


    /* CLOSE SHOP MENU WHEN CLICKING OUTSIDE */
    document.addEventListener('click', function (event) {

        if (!shopMenu) {
            return;
        }

        if (!shopMenu.contains(event.target)) {

            shopMenu.classList.remove('tm-shop-open');

            document.querySelectorAll('.tm-submenu.tm-submenu-open').forEach(function (submenu) {
                submenu.classList.remove('tm-submenu-open');
            });

        }

    });

});
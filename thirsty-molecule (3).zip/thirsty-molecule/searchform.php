<?php
/**
 * Search form.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

$tm_id = 'tm-search-' . wp_unique_id();
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $tm_id ); ?>"><?php esc_html_e( 'Search', 'thirsty-molecule' ); ?></label>
	<input id="<?php echo esc_attr( $tm_id ); ?>" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search…', 'thirsty-molecule' ); ?>" />
	<button type="submit"><?php esc_html_e( 'Search', 'thirsty-molecule' ); ?></button>
</form>

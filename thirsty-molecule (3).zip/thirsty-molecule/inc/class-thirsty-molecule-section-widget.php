<?php
/**
 * Base Elementor widget that renders a Thirsty Molecule section template part.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor\\Widget_Base' ) ) {
	return;
}

/**
 * Renders one `template-parts/section-{slug}.php` file as an Elementor widget.
 */
abstract class Thirsty_Molecule_Section_Widget extends \Elementor\Widget_Base {

	/**
	 * Section slug, e.g. `hero`.
	 *
	 * @var string
	 */
	protected $section = '';

	/**
	 * Human readable label.
	 *
	 * @var string
	 */
	protected $label = '';

	/**
	 * Widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'tm-section-' . $this->section;
	}

	/**
	 * Widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return $this->label;
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-single-page';
	}

	/**
	 * Widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'thirsty-molecule' );
	}

	/**
	 * Search keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return array( 'thirsty', 'molecule', 'section', $this->section );
	}

	/**
	 * Widget controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'tm_section_content',
			array(
				'label' => __( 'Section', 'thirsty-molecule' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'tm_section_notice',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					/* translators: %s: section label. */
					esc_html__( 'Text and images for the %s section are edited in Appearance → Customize → Thirsty Molecule.', 'thirsty-molecule' ),
					esc_html( $this->label )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_responsive_control(
			'tm_section_spacing',
			array(
				'label'      => __( 'Outer spacing', 'thirsty-molecule' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'rem', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .tm-elementor-section' => 'margin:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Frontend output.
	 *
	 * @return void
	 */
	protected function render() {
		echo '<div class="tm-elementor-section tm-elementor-section--' . esc_attr( $this->section ) . '">';
		get_template_part( 'template-parts/section', $this->section );
		echo '</div>';
	}
}

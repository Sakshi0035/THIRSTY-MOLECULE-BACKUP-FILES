<?php
/**
 * Elementor widgets for each Thirsty Molecule landing page section.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Thirsty_Molecule_Section_Widget' ) ) {
	return;
}

/**
 * Hero Carousel section widget.
 */
class Thirsty_Molecule_Widget_Hero extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'hero';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Hero Carousel', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slides';
	}
}

/**
 * Trust Strip section widget.
 */
class Thirsty_Molecule_Widget_Trust extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'trust';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Trust Strip', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-check-circle';
	}
}

/**
 * Ticker section widget.
 */
class Thirsty_Molecule_Widget_Ticker extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'ticker';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Ticker', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-animation-text';
	}
}

/**
 * Product Range section widget.
 */
class Thirsty_Molecule_Widget_Range extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'range';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Product Range', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-products';
	}
}

/**
 * Editorial Feature section widget.
 */
class Thirsty_Molecule_Widget_Editorial extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'editorial';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Editorial Feature', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image-box';
	}
}

/**
 * Positioning section widget.
 */
class Thirsty_Molecule_Widget_Positioning extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'positioning';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Positioning', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-text';
	}
}

/**
 * What Makes Us Different section widget.
 */
class Thirsty_Molecule_Widget_Different extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'different';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'What Makes Us Different', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-info-box';
	}
}

/**
 * Values Grid section widget.
 */
class Thirsty_Molecule_Widget_Values extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'values';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Values Grid', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}
}

/**
 * Brand Story section widget.
 */
class Thirsty_Molecule_Widget_Story extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'story';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Brand Story', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-post-content';
	}
}

/**
 * Reviews section widget.
 */
class Thirsty_Molecule_Widget_Reviews extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'reviews';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Reviews', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}
}

/**
 * Signup / Newsletter section widget.
 */
class Thirsty_Molecule_Widget_Signup extends Thirsty_Molecule_Section_Widget {
	/**
	 * Section slug.
	 *
	 * @var string
	 */
	protected $section = 'signup';

	/**
	 * Constructor.
	 *
	 * @param array $data Widget data.
	 * @param array $args Widget args.
	 */
	public function __construct( $data = array(), $args = null ) {
		$this->label = __( 'Signup / Newsletter', 'thirsty-molecule' );
		parent::__construct( $data, $args );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-email-field';
	}
}


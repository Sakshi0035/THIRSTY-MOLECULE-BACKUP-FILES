<?php
/**
 * Elementor integration.
 *
 * Makes the theme work well with the FREE version of Elementor:
 * - declares full-width / canvas friendly support,
 * - registers a "Thirsty Molecule" widget category,
 * - exposes every landing page section as a drag & drop widget,
 * - registers theme locations for Elementor Pro's Theme Builder (optional),
 * - drops theme container padding on Elementor-built pages.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is Elementor active?
 *
 * @return bool
 */
function thirsty_molecule_has_elementor() {
	return did_action( 'elementor/loaded' ) || class_exists( '\\Elementor\\Plugin' );
}

/**
 * Declare Elementor related theme support.
 *
 * @return void
 */
function thirsty_molecule_elementor_setup() {
	// Let Elementor style the whole page area.
	add_theme_support( 'elementor' );
	add_theme_support( 'align-wide' );

	// Header/footer experiment support (Elementor 3.x).
	add_theme_support( 'header-footer-elementor' );
}
add_action( 'after_setup_theme', 'thirsty_molecule_elementor_setup' );

/**
 * Register the theme widget category.
 *
 * @param object $elements_manager Elementor elements manager.
 * @return void
 */
function thirsty_molecule_elementor_category( $elements_manager ) {
	$elements_manager->add_category(
		'thirsty-molecule',
		array(
			'title' => __( 'Thirsty Molecule', 'thirsty-molecule' ),
			'icon'  => 'fa fa-plug',
		)
	);
}
add_action( 'elementor/elements/categories_registered', 'thirsty_molecule_elementor_category' );

/**
 * Register the section widgets.
 *
 * @param object $widgets_manager Elementor widgets manager.
 * @return void
 */
function thirsty_molecule_register_elementor_widgets( $widgets_manager ) {
	require_once get_template_directory() . '/inc/class-thirsty-molecule-section-widget.php';
	require_once get_template_directory() . '/inc/elementor-widgets.php';

	$widgets = array(
		'Thirsty_Molecule_Widget_Hero',
		'Thirsty_Molecule_Widget_Trust',
		'Thirsty_Molecule_Widget_Ticker',
		'Thirsty_Molecule_Widget_Range',
		'Thirsty_Molecule_Widget_Editorial',
		'Thirsty_Molecule_Widget_Positioning',
		'Thirsty_Molecule_Widget_Different',
		'Thirsty_Molecule_Widget_Values',
		'Thirsty_Molecule_Widget_Story',
		'Thirsty_Molecule_Widget_Reviews',
		'Thirsty_Molecule_Widget_Signup',
	);

	foreach ( $widgets as $widget ) {
		if ( ! class_exists( $widget ) ) {
			continue;
		}

		if ( method_exists( $widgets_manager, 'register' ) ) {
			$widgets_manager->register( new $widget() );
		} else {
			$widgets_manager->register_widget_type( new $widget() );
		}
	}
}
add_action( 'elementor/widgets/register', 'thirsty_molecule_register_elementor_widgets' );
add_action( 'elementor/widgets/widgets_registered', 'thirsty_molecule_register_elementor_widgets' );

/**
 * Register Theme Builder locations (used when Elementor Pro is installed).
 * With free Elementor these simply never fire, and the theme templates render.
 *
 * @param object $manager Elementor theme locations manager.
 * @return void
 */
function thirsty_molecule_elementor_locations( $manager ) {
	$manager->register_all_core_location();
}
add_action( 'elementor/theme/register_locations', 'thirsty_molecule_elementor_locations' );

/**
 * Body classes that help Elementor pages go edge to edge.
 *
 * @param array $classes Body classes.
 * @return array
 */
function thirsty_molecule_elementor_body_class( $classes ) {
	if ( ! thirsty_molecule_has_elementor() || ! is_singular() ) {
		return $classes;
	}

	$post_id = get_queried_object_id();

	if ( $post_id && class_exists( '\\Elementor\\Plugin' ) ) {
		$documents = \Elementor\Plugin::$instance->documents;

		if ( $documents && method_exists( $documents, 'get' ) ) {
			$document = $documents->get( $post_id );

			if ( $document && $document->is_built_with_elementor() ) {
				$classes[] = 'tm-elementor-page';
			}
		}
	}

	return $classes;
}
add_filter( 'body_class', 'thirsty_molecule_elementor_body_class' );

/**
 * Load the small Elementor compatibility stylesheet.
 *
 * @return void
 */
function thirsty_molecule_elementor_styles() {
	if ( ! thirsty_molecule_has_elementor() ) {
		return;
	}

	wp_enqueue_style(
		'thirsty-molecule-elementor',
		get_template_directory_uri() . '/assets/css/elementor.css',
		array( 'thirsty-molecule-main' ),
		THIRSTY_MOLECULE_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'thirsty_molecule_elementor_styles', 20 );

/**
 * Make the theme palette available as Elementor global colors/fonts defaults.
 *
 * @param array $data Kit default settings.
 * @return array
 */
function thirsty_molecule_elementor_kit_defaults( $data ) {
	$data['system_colors'] = array(
		array(
			'_id'   => 'primary',
			'title' => __( 'Pink', 'thirsty-molecule' ),
			'color' => '#E40088',
		),
		array(
			'_id'   => 'secondary',
			'title' => __( 'Aqua', 'thirsty-molecule' ),
			'color' => '#61D3D8',
		),
		array(
			'_id'   => 'text',
			'title' => __( 'Ink', 'thirsty-molecule' ),
			'color' => '#101010',
		),
		array(
			'_id'   => 'accent',
			'title' => __( 'Orange', 'thirsty-molecule' ),
			'color' => '#EE7808',
		),
	);

	$data['custom_colors'] = array(
		array(
			'_id'   => 'tmpurple',
			'title' => __( 'Purple', 'thirsty-molecule' ),
			'color' => '#762BB7',
		),
		array(
			'_id'   => 'tmyellow',
			'title' => __( 'Yellow', 'thirsty-molecule' ),
			'color' => '#E6E416',
		),
	);

	$data['system_typography'] = array(
		array(
			'_id'                => 'primary',
			'title'              => __( 'Headings', 'thirsty-molecule' ),
			'typography_typography'  => 'custom',
			'typography_font_family' => 'Fredoka',
			'typography_font_weight' => '700',
		),
		array(
			'_id'                => 'secondary',
			'title'              => __( 'Subheadings', 'thirsty-molecule' ),
			'typography_typography'  => 'custom',
			'typography_font_family' => 'Fredoka',
			'typography_font_weight' => '600',
		),
		array(
			'_id'                => 'text',
			'title'              => __( 'Body', 'thirsty-molecule' ),
			'typography_typography'  => 'custom',
			'typography_font_family' => 'Montserrat',
			'typography_font_weight' => '500',
		),
		array(
			'_id'                => 'accent',
			'title'              => __( 'Accent', 'thirsty-molecule' ),
			'typography_typography'  => 'custom',
			'typography_font_family' => 'Fredoka',
			'typography_font_weight' => '700',
		),
	);

	return $data;
}
add_filter( 'elementor/kit/default_settings', 'thirsty_molecule_elementor_kit_defaults' );

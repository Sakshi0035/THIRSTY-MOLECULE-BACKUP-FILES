<?php
/**
 * Reusable template helpers.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

/**
 * Print the site branding (custom logo or the Thirsty Molecule wordmark).
 *
 * @return void
 */
function thirsty_molecule_branding() {
	if ( has_custom_logo() ) {
		echo '<span class="wordmark wordmark-image">';
		the_custom_logo();
		echo '</span>';

		return;
	}

	$name  = get_bloginfo( 'name', 'display' );
	$parts = preg_split( '/\s+/', trim( $name ), 2 );
	$first = isset( $parts[0] ) ? $parts[0] : 'THIRSTY';
	$rest  = isset( $parts[1] ) ? $parts[1] : 'MOLECULE';

	printf(
		'<a class="wordmark" href="%1$s" rel="home">%2$s<br /><span>%3$s</span></a>',
		esc_url( home_url( '/' ) ),
		esc_html( strtoupper( $first ) ),
		esc_html( strtoupper( $rest ) )
	);
}

/**
 * Post meta line.
 *
 * @return void
 */
function thirsty_molecule_entry_meta() {
	printf(
		'<p class="entry-meta">%1$s &middot; %2$s</p>',
		esc_html( get_the_date() ),
		esc_html( get_the_author() )
	);
}

/**
 * Pagination.
 *
 * @return void
 */
function thirsty_molecule_pagination() {
	the_posts_pagination(
		array(
			'class'     => 'tm-pagination',
			'mid_size'  => 2,
			'prev_text' => esc_html__( 'Prev', 'thirsty-molecule' ),
			'next_text' => esc_html__( 'Next', 'thirsty-molecule' ),
		)
	);
}

/**
 * Footer navigation column, falling back to static links when no menu is set.
 *
 * @param string $location Menu location.
 * @param array  $fallback Fallback links (label => url).
 * @return void
 */
function thirsty_molecule_footer_links( $location, $fallback ) {
	if ( has_nav_menu( $location ) ) {
		wp_nav_menu(
			array(
				'theme_location' => $location,
				'container'      => false,
				'items_wrap'     => '<ul class="footer-menu">%3$s</ul>',
				'depth'          => 1,
				'fallback_cb'    => false,
			)
		);

		return;
	}

	foreach ( $fallback as $label => $url ) {
		printf( '<a href="%1$s">%2$s</a>', esc_url( $url ), esc_html( $label ) );
	}
}

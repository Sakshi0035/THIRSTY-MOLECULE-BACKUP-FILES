<?php
/**
 * Customizer registration for editable front-page content.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register a text control.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 * @param string               $section      Section id.
 * @param string               $id           Setting id.
 * @param string               $label        Label.
 * @param string               $default      Default value.
 * @param string               $type         Control type: text, textarea, url, checkbox.
 * @return void
 */
function thirsty_molecule_add_field( $wp_customize, $section, $id, $label, $default = '', $type = 'text' ) {
	$sanitize = 'sanitize_text_field';

	if ( 'textarea' === $type ) {
		$sanitize = 'wp_kses_post';
	} elseif ( 'url' === $type ) {
		$sanitize = 'thirsty_molecule_sanitize_link';
	} elseif ( 'checkbox' === $type ) {
		$sanitize = 'thirsty_molecule_sanitize_checkbox';
	}

	$wp_customize->add_setting(
		$id,
		array(
			'default'           => $default,
			'sanitize_callback' => $sanitize,
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		$id,
		array(
			'label'   => $label,
			'section' => $section,
			'type'    => 'checkbox' === $type ? 'checkbox' : ( 'textarea' === $type ? 'textarea' : 'text' ),
		)
	);
}

/**
 * Register an image control.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 * @param string               $section      Section id.
 * @param string               $id           Setting id.
 * @param string               $label        Label.
 * @param string               $default      Default URL.
 * @return void
 */
function thirsty_molecule_add_image( $wp_customize, $section, $id, $label, $default = '' ) {
	$wp_customize->add_setting(
		$id,
		array(
			'default'           => $default,
			'sanitize_callback' => 'esc_url_raw',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			$id,
			array(
				'label'   => $label,
				'section' => $section,
			)
		)
	);
}

/**
 * Sanitize a link that may be a URL or an in-page anchor.
 *
 * @param string $value Raw value.
 * @return string
 */
function thirsty_molecule_sanitize_link( $value ) {
	$value = trim( (string) $value );

	if ( '' !== $value && '#' === $value[0] ) {
		return '#' . sanitize_title( substr( $value, 1 ) );
	}

	return esc_url_raw( $value );
}

/**
 * Sanitize a checkbox.
 *
 * @param mixed $value Raw value.
 * @return bool
 */
function thirsty_molecule_sanitize_checkbox( $value ) {
	return (bool) $value;
}

/**
 * Register Customizer panels, sections and settings.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @return void
 */
function thirsty_molecule_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport        = 'refresh';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'refresh';

	$wp_customize->add_panel(
		'tm_front',
		array(
			'title'       => __( 'Thirsty Molecule Front Page', 'thirsty-molecule' ),
			'description' => __( 'Edit every section of the landing page.', 'thirsty-molecule' ),
			'priority'    => 20,
		)
	);

	/* --- Header --- */
	$wp_customize->add_section( 'tm_header', array( 'title' => __( 'Header', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	thirsty_molecule_add_field( $wp_customize, 'tm_header', 'tm_nav_cta_label', __( 'Header button label', 'thirsty-molecule' ), 'Shop now' );
	thirsty_molecule_add_field( $wp_customize, 'tm_header', 'tm_nav_cta_url', __( 'Header button link', 'thirsty-molecule' ), '#range', 'url' );

	/* --- Hero slides --- */
	$slide_defaults = array(
		1 => array( 'CLEANSE · CETAGLOW', 'Cleans without the plot twist.', 'Shop CetaGlow', 'cetaglow-clean-v2.png' ),
		2 => array( 'HYDRATE · HYDRAMATRIX', 'Thirsty skin behaves better.', 'Shop HydraMatrix', 'hydramatrix-clean-v2.png' ),
		3 => array( 'BRIGHTEN · AURI — COMING SOON', 'Even tone, zero drama.', 'Get notified', 'auri.png' ),
		4 => array( 'RENEW · IMMORIA — COMING SOON', 'Peptides that mean business.', 'Get notified', 'immoria.png' ),
	);

	foreach ( $slide_defaults as $n => $data ) {
		$section = 'tm_slide' . $n;
		$wp_customize->add_section(
			$section,
			array(
				/* translators: %d: slide number. */
				'title' => sprintf( __( 'Hero slide %d', 'thirsty-molecule' ), $n ),
				'panel' => 'tm_front',
			)
		);
		thirsty_molecule_add_field( $wp_customize, $section, "tm_slide{$n}_ritual", __( 'Eyebrow', 'thirsty-molecule' ), $data[0] );
		thirsty_molecule_add_field( $wp_customize, $section, "tm_slide{$n}_title", __( 'Heading', 'thirsty-molecule' ), $data[1] );
		thirsty_molecule_add_field( $wp_customize, $section, "tm_slide{$n}_text", __( 'Text', 'thirsty-molecule' ), '', 'textarea' );
		thirsty_molecule_add_field( $wp_customize, $section, "tm_slide{$n}_primary", __( 'Primary button label', 'thirsty-molecule' ), $data[2] );
		thirsty_molecule_add_field( $wp_customize, $section, "tm_slide{$n}_primary_url", __( 'Primary button link', 'thirsty-molecule' ), '#range', 'url' );
		thirsty_molecule_add_field( $wp_customize, $section, "tm_slide{$n}_secondary", __( 'Secondary button label', 'thirsty-molecule' ), '' );
		thirsty_molecule_add_field( $wp_customize, $section, "tm_slide{$n}_secondary_url", __( 'Secondary button link', 'thirsty-molecule' ), '#range', 'url' );
		thirsty_molecule_add_image( $wp_customize, $section, "tm_slide{$n}_image", __( 'Product image', 'thirsty-molecule' ), thirsty_molecule_image( $data[3] ) );
		thirsty_molecule_add_field( $wp_customize, $section, "tm_slide{$n}_show_product", __( 'Show product image', 'thirsty-molecule' ), $n <= 2, 'checkbox' );
	}

	/* --- Trust strip --- */
	$wp_customize->add_section( 'tm_trust', array( 'title' => __( 'Trust badges', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	for ( $n = 1; $n <= 3; $n++ ) {
		/* translators: %d: badge number. */
		thirsty_molecule_add_field( $wp_customize, 'tm_trust', "tm_trust{$n}_title", sprintf( __( 'Badge %d title', 'thirsty-molecule' ), $n ) );
		/* translators: %d: badge number. */
		thirsty_molecule_add_field( $wp_customize, 'tm_trust', "tm_trust{$n}_text", sprintf( __( 'Badge %d text', 'thirsty-molecule' ), $n ) );
	}

	/* --- Ticker --- */
	$wp_customize->add_section( 'tm_ticker', array( 'title' => __( 'Ticker', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	thirsty_molecule_add_field( $wp_customize, 'tm_ticker', 'tm_ticker_1', __( 'Phrase 1', 'thirsty-molecule' ), 'HYDRATION FIRST' );
	thirsty_molecule_add_field( $wp_customize, 'tm_ticker', 'tm_ticker_2', __( 'Phrase 2', 'thirsty-molecule' ), 'FORMULA, NOT FOLKLORE' );
	thirsty_molecule_add_field( $wp_customize, 'tm_ticker', 'tm_ticker_3', __( 'Phrase 3', 'thirsty-molecule' ), 'NO DECORATIVE ACTIVES' );

	/* --- Range --- */
	$wp_customize->add_section( 'tm_range', array( 'title' => __( 'The range', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	thirsty_molecule_add_field( $wp_customize, 'tm_range', 'tm_range_heading', __( 'Section heading', 'thirsty-molecule' ), 'The range, so far.' );
	thirsty_molecule_add_field( $wp_customize, 'tm_range', 'tm_range_all_label', __( '"View all" label', 'thirsty-molecule' ), 'View all products' );
	thirsty_molecule_add_field( $wp_customize, 'tm_range', 'tm_range_all_url', __( '"View all" link', 'thirsty-molecule' ), '#range', 'url' );
	for ( $n = 1; $n <= 4; $n++ ) {
		/* translators: %d: card number. */
		$prefix = sprintf( __( 'Card %d', 'thirsty-molecule' ), $n ) . ' – ';
		thirsty_molecule_add_field( $wp_customize, 'tm_range', "tm_range{$n}_tag", $prefix . __( 'tag', 'thirsty-molecule' ) );
		thirsty_molecule_add_field( $wp_customize, 'tm_range', "tm_range{$n}_name", $prefix . __( 'name', 'thirsty-molecule' ) );
		thirsty_molecule_add_field( $wp_customize, 'tm_range', "tm_range{$n}_text", $prefix . __( 'description', 'thirsty-molecule' ) );
		thirsty_molecule_add_field( $wp_customize, 'tm_range', "tm_range{$n}_chip1", $prefix . __( 'chip 1', 'thirsty-molecule' ) );
		thirsty_molecule_add_field( $wp_customize, 'tm_range', "tm_range{$n}_chip2", $prefix . __( 'chip 2', 'thirsty-molecule' ) );
		thirsty_molecule_add_field( $wp_customize, 'tm_range', "tm_range{$n}_price", $prefix . __( 'price', 'thirsty-molecule' ) );
		thirsty_molecule_add_field( $wp_customize, 'tm_range', "tm_range{$n}_button", $prefix . __( 'button label', 'thirsty-molecule' ) );
		thirsty_molecule_add_field( $wp_customize, 'tm_range', "tm_range{$n}_url", $prefix . __( 'button link', 'thirsty-molecule' ), '#range', 'url' );
		thirsty_molecule_add_image( $wp_customize, 'tm_range', "tm_range{$n}_image", $prefix . __( 'image', 'thirsty-molecule' ) );
	}

	/* --- Editorial --- */
	$wp_customize->add_section( 'tm_editorial', array( 'title' => __( 'Editorial banner', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	thirsty_molecule_add_image( $wp_customize, 'tm_editorial', 'tm_editorial_image', __( 'Image', 'thirsty-molecule' ), thirsty_molecule_image( 'hydramatrix-editorial-model-funky.jpg' ) );
	thirsty_molecule_add_field( $wp_customize, 'tm_editorial', 'tm_editorial_alt', __( 'Image alt text', 'thirsty-molecule' ), 'Joyful woman holding HydraMatrix moisturizer' );
	thirsty_molecule_add_field( $wp_customize, 'tm_editorial', 'tm_editorial_kicker', __( 'Kicker', 'thirsty-molecule' ), 'HYDRATION, CAUGHT SMILING' );
	thirsty_molecule_add_field( $wp_customize, 'tm_editorial', 'tm_editorial_heading', __( 'Heading', 'thirsty-molecule' ), 'Hydration looks good on you.' );
	thirsty_molecule_add_field( $wp_customize, 'tm_editorial', 'tm_editorial_text', __( 'Text', 'thirsty-molecule' ), '', 'textarea' );
	thirsty_molecule_add_field( $wp_customize, 'tm_editorial', 'tm_editorial_cta', __( 'Button label', 'thirsty-molecule' ), 'Meet HydraMatrix' );
	thirsty_molecule_add_field( $wp_customize, 'tm_editorial', 'tm_editorial_url', __( 'Button link', 'thirsty-molecule' ), '#range', 'url' );

	/* --- Positioning / different / values / story --- */
	$wp_customize->add_section( 'tm_story', array( 'title' => __( 'Brand story sections', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_positioning_kicker', __( 'Positioning kicker (blank = hidden)', 'thirsty-molecule' ), '' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_positioning_text', __( 'Positioning paragraph', 'thirsty-molecule' ), '', 'textarea' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_different_kicker', __( 'Difference kicker', 'thirsty-molecule' ), 'WHAT MAKES US DIFFERENT' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_different_heading', __( 'Difference heading', 'thirsty-molecule' ), '' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_different_text1', __( 'Difference paragraph 1', 'thirsty-molecule' ), '', 'textarea' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_different_text2', __( 'Difference paragraph 2', 'thirsty-molecule' ), '', 'textarea' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_why_heading', __( 'Values heading', 'thirsty-molecule' ), 'What we won’t compromise on.' );
	for ( $n = 1; $n <= 3; $n++ ) {
		/* translators: %d: value number. */
		thirsty_molecule_add_field( $wp_customize, 'tm_story', "tm_value{$n}_title", sprintf( __( 'Value %d title', 'thirsty-molecule' ), $n ) );
		/* translators: %d: value number. */
		thirsty_molecule_add_field( $wp_customize, 'tm_story', "tm_value{$n}_text", sprintf( __( 'Value %d text', 'thirsty-molecule' ), $n ), '', 'textarea' );
	}
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_story_heading', __( 'Story heading', 'thirsty-molecule' ), 'Formula, not folklore.' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_story_text1', __( 'Story paragraph 1', 'thirsty-molecule' ), '', 'textarea' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_story_text2', __( 'Story paragraph 2', 'thirsty-molecule' ), '', 'textarea' );
	thirsty_molecule_add_field( $wp_customize, 'tm_story', 'tm_story_note', __( 'Story highlight', 'thirsty-molecule' ), '— No decorative actives. No miracle timelines.' );

	/* --- Reviews --- */
	$wp_customize->add_section( 'tm_reviews', array( 'title' => __( 'Reviews', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	thirsty_molecule_add_field( $wp_customize, 'tm_reviews', 'tm_reviews_heading', __( 'Heading', 'thirsty-molecule' ), 'Skin has opinions.' );
	thirsty_molecule_add_field( $wp_customize, 'tm_reviews', 'tm_reviews_intro', __( 'Intro', 'thirsty-molecule' ), 'Fortunately, some of them are very flattering.' );
	for ( $n = 1; $n <= 3; $n++ ) {
		/* translators: %d: review number. */
		$prefix = sprintf( __( 'Review %d', 'thirsty-molecule' ), $n ) . ' – ';
		thirsty_molecule_add_field( $wp_customize, 'tm_reviews', "tm_review{$n}_title", $prefix . __( 'headline', 'thirsty-molecule' ) );
		thirsty_molecule_add_field( $wp_customize, 'tm_reviews', "tm_review{$n}_text", $prefix . __( 'text', 'thirsty-molecule' ), '', 'textarea' );
		thirsty_molecule_add_field( $wp_customize, 'tm_reviews', "tm_review{$n}_author", $prefix . __( 'author', 'thirsty-molecule' ) );
	}

	/* --- Signup --- */
	$wp_customize->add_section( 'tm_signup', array( 'title' => __( 'Signup band', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	thirsty_molecule_add_field( $wp_customize, 'tm_signup', 'tm_signup_kicker', __( 'Kicker', 'thirsty-molecule' ), 'THE LAB LIST' );
	thirsty_molecule_add_field( $wp_customize, 'tm_signup', 'tm_signup_heading', __( 'Heading', 'thirsty-molecule' ), 'Know when the next molecule drops.' );
	thirsty_molecule_add_field( $wp_customize, 'tm_signup', 'tm_signup_text', __( 'Text', 'thirsty-molecule' ), '', 'textarea' );
	thirsty_molecule_add_field( $wp_customize, 'tm_signup', 'tm_signup_button', __( 'Button label', 'thirsty-molecule' ), 'Keep me posted' );
	thirsty_molecule_add_field( $wp_customize, 'tm_signup', 'tm_signup_action', __( 'Form action URL (optional)', 'thirsty-molecule' ), '', 'url' );

	/* --- Footer & contact --- */
	$wp_customize->add_section( 'tm_footer', array( 'title' => __( 'Footer & contact', 'thirsty-molecule' ), 'panel' => 'tm_front' ) );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_footer_tagline', __( 'Tagline', 'thirsty-molecule' ), 'Hydration first. Everything good follows.' );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_footer_email', __( 'Contact email', 'thirsty-molecule' ), 'hello@thirstymolecule.com' );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_footer_phone', __( 'Contact phone', 'thirsty-molecule' ), '' );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_footer_address', __( 'Address', 'thirsty-molecule' ), '' );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_social_instagram', __( 'Instagram URL', 'thirsty-molecule' ), '#', 'url' );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_social_linkedin', __( 'LinkedIn URL', 'thirsty-molecule' ), '#', 'url' );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_social_facebook', __( 'Facebook URL', 'thirsty-molecule' ), '', 'url' );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_footer_copyright', __( 'Copyright line', 'thirsty-molecule' ), '' );
	thirsty_molecule_add_field( $wp_customize, 'tm_footer', 'tm_footer_note', __( 'Footer right-hand note', 'thirsty-molecule' ), 'Formula, not folklore.' );
}
add_action( 'customize_register', 'thirsty_molecule_customize_register' );

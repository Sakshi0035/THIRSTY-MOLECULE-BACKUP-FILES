<?php
/**
 * Default front-page content.
 *
 * Every value below is overridable from the Customizer
 * (Appearance -> Customize -> Thirsty Molecule Front Page).
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

/**
 * Theme image URL helper.
 *
 * @param string $file File name inside assets/images.
 * @return string
 */
function thirsty_molecule_image( $file ) {
	return get_template_directory_uri() . '/assets/images/' . ltrim( $file, '/' );
}

/**
 * Read a theme mod with a default fallback.
 *
 * @param string $key     Setting key.
 * @param mixed  $default Default value.
 * @return mixed
 */
function thirsty_molecule_mod( $key, $default = '' ) {
	$value = get_theme_mod( $key, $default );

	return ( '' === $value || null === $value ) ? $default : $value;
}

/**
 * Hero carousel slides.
 *
 * @return array
 */
function thirsty_molecule_slides() {
	$defaults = array(
		array(
			'id'           => 'cetaglow',
			'ritual'       => 'CLEANSE · CETAGLOW',
			'title'        => 'Cleans without the plot twist.',
			'text'         => 'A gentle, non-foaming cream cleanser that removes everyday dirt and excess oil—without leaving skin tight, dry or stripped.',
			'primary'      => 'Shop CetaGlow',
			'secondary'    => '',
			'image'        => thirsty_molecule_image( 'cetaglow-clean-v2.png' ),
			'show_product' => true,
		),
		array(
			'id'           => 'hydramatrix',
			'ritual'       => 'HYDRATE · HYDRAMATRIX',
			'title'        => 'Thirsty skin behaves better.',
			'text'         => 'A lightweight gel-cream moisturizer for lasting hydration, a healthier moisture barrier and dewy-looking skin—without the greasy aftermath.',
			'primary'      => 'Shop HydraMatrix',
			'secondary'    => '',
			'image'        => thirsty_molecule_image( 'hydramatrix-clean-v2.png' ),
			'show_product' => true,
		),
		array(
			'id'           => 'auri',
			'ritual'       => 'BRIGHTEN · COMING SOON',
			'title'        => 'Even tone, zero drama.',
			'text'         => 'A brightening face serum is currently bubbling in the lab.',
			'primary'      => 'Notify me',
			'secondary'    => '',
			'image'        => thirsty_molecule_image( 'auri.png' ),
			'show_product' => false,
		),
		array(
			'id'           => 'immoria',
			'ritual'       => 'RENEW · COMING SOON',
			'title'        => 'Peptides that mean business.',
			'text'         => 'An advanced peptide serum is currently getting its final laboratory interrogation.',
			'primary'      => 'Notify me',
			'secondary'    => '',
			'image'        => thirsty_molecule_image( 'immoria.png' ),
			'show_product' => false,
		),
	);

	$slides = array();

	foreach ( $defaults as $index => $slide ) {
		$n     = $index + 1;
		$image = thirsty_molecule_mod( "tm_slide{$n}_image", $slide['image'] );

		$slides[] = array(
			'id'            => $slide['id'],
			'ritual'        => thirsty_molecule_mod( "tm_slide{$n}_ritual", $slide['ritual'] ),
			'title'         => thirsty_molecule_mod( "tm_slide{$n}_title", $slide['title'] ),
			'text'          => thirsty_molecule_mod( "tm_slide{$n}_text", $slide['text'] ),
			'primary'       => thirsty_molecule_mod( "tm_slide{$n}_primary", $slide['primary'] ),
			'primary_url'   => thirsty_molecule_mod( "tm_slide{$n}_primary_url", '#range' ),
			'secondary'     => get_theme_mod( "tm_slide{$n}_secondary", $slide['secondary'] ),
			'secondary_url' => thirsty_molecule_mod( "tm_slide{$n}_secondary_url", '#range' ),
			'image'         => $image,
			'show_product'  => (bool) get_theme_mod( "tm_slide{$n}_show_product", $slide['show_product'] ),
		);
	}

	return apply_filters( 'thirsty_molecule_slides', $slides );
}

/**
 * Trust badges.
 *
 * @return array
 */
function thirsty_molecule_trust() {
	return apply_filters(
		'thirsty_molecule_trust',
		array(
			array( 'icon' => '⚗', 'class' => 'flask', 'title' => thirsty_molecule_mod( 'tm_trust1_title', 'Formulator-led' ), 'text' => thirsty_molecule_mod( 'tm_trust1_text', 'Ingredients, levels and pH—checked.' ) ),
			array( 'icon' => '🐰', 'class' => 'bunny', 'title' => thirsty_molecule_mod( 'tm_trust2_title', 'No animal testing' ), 'text' => thirsty_molecule_mod( 'tm_trust2_text', 'Good formulas need no villain arc.' ) ),
			array( 'icon' => 'Ø', 'class' => 'free', 'title' => thirsty_molecule_mod( 'tm_trust3_title', 'Free from the fuss' ), 'text' => thirsty_molecule_mod( 'tm_trust3_text', 'No SLS/SLES. No parabens.' ) ),
		)
	);
}

/**
 * Range (product) cards.
 *
 * @return array
 */
function thirsty_molecule_range() {
	$defaults = array(
		array( '', 'CetaGlow', 'Non-Foaming Cream Cleanser', 'Gently removes dirt and excess oil without leaving skin tight, dry or stripped.', '2% Niacinamide · Hyaluronic Acid', 'Pro-Vitamin B5 · Jojoba Oil', '₹395', 'Shop CetaGlow', 'cetaglow.png' ),
		array( '', 'HydraMatrix', 'Lightweight Gel-Cream Moisturizer', 'Delivers lasting hydration and barrier support—without the greasy aftermath.', '2% Pentavitin® · 8M Hyaluronic Acid', 'Triple Ceramides', '₹950', 'Shop HydraMatrix', 'hydramatrix.png' ),
		array( 'BRIGHTEN', 'Coming soon', '', 'Even tone, zero drama.', '', '', '', 'Notify me', 'auri.png' ),
		array( 'RENEW', 'Coming soon', '', 'Peptides that mean business.', '', '', '', 'Notify me', 'immoria.png' ),
	);

	$cards = array();

	foreach ( $defaults as $index => $item ) {
		$n = $index + 1;

		$cards[] = array(
			'tag'    => get_theme_mod( "tm_range{$n}_tag", $item[0] ),
			'name'   => thirsty_molecule_mod( "tm_range{$n}_name", $item[1] ),
			'sub'    => get_theme_mod( "tm_range{$n}_sub", $item[2] ),
			'text'   => get_theme_mod( "tm_range{$n}_text", $item[3] ),
			'chip1'  => get_theme_mod( "tm_range{$n}_chip1", $item[4] ),
			'chip2'  => get_theme_mod( "tm_range{$n}_chip2", $item[5] ),
			'price'  => get_theme_mod( "tm_range{$n}_price", $item[6] ),
			'button' => thirsty_molecule_mod( "tm_range{$n}_button", $item[7] ),
			'url'    => thirsty_molecule_mod( "tm_range{$n}_url", '#range' ),
			'image'  => thirsty_molecule_mod( "tm_range{$n}_image", thirsty_molecule_image( $item[8] ) ),
		);
	}

	return apply_filters( 'thirsty_molecule_range', $cards );
}

/**
 * Values ("Why us") cards.
 *
 * @return array
 */
function thirsty_molecule_values() {
	$defaults = array(
		array( '01', 'Obsessive Formulas', 'Ingredients, concentrations, compatibility and pH—Tara checks the lot. “Close enough” has never been part of the formula.' ),
		array( '02', 'Skin-Respecting Results', 'We formulate for visible results without picking a fight with your skin barrier.' ),
		array( '03', 'Integrity, Always', 'No miracle timelines. No decorative actives. Just thoughtful formulas and benefits we can genuinely stand behind.' ),
	);

	$items = array();

	foreach ( $defaults as $index => $item ) {
		$n       = $index + 1;
		$items[] = array(
			'number' => $item[0],
			'title'  => thirsty_molecule_mod( "tm_value{$n}_title", $item[1] ),
			'text'   => thirsty_molecule_mod( "tm_value{$n}_text", $item[2] ),
		);
	}

	return apply_filters( 'thirsty_molecule_values', $items );
}

/**
 * Review cards.
 *
 * @return array
 */
function thirsty_molecule_reviews() {
	$defaults = array(
		array( '“The tight feeling packed its bags.”', 'Sample review copy for CetaGlow will appear here once verified customer feedback is available.', '— Customer name' ),
		array( '“Dewy. Bouncy. Zero grease.”', 'Sample review copy for HydraMatrix will appear here once verified customer feedback is available.', '— Customer name' ),
		array( '“My barrier sent a thank-you note.”', 'Use this card for a short verified review—specific, readable and refreshingly drama-free.', '— Customer name' ),
	);

	$items = array();

	foreach ( $defaults as $index => $item ) {
		$n       = $index + 1;
		$items[] = array(
			'title'  => thirsty_molecule_mod( "tm_review{$n}_title", $item[0] ),
			'text'   => thirsty_molecule_mod( "tm_review{$n}_text", $item[1] ),
			'author' => thirsty_molecule_mod( "tm_review{$n}_author", $item[2] ),
		);
	}

	return apply_filters( 'thirsty_molecule_reviews', $items );
}

<?php
/**
 * Seeds the Home page with ready-made Elementor HTML widgets.
 *
 * Every landing page section is captured as raw HTML (exactly as the theme
 * renders it) and stored inside its own Elementor "HTML" widget, so the page
 * is already complete when the user clicks "Edit with Elementor".
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sections that become HTML widgets, in page order.
 *
 * @return array slug => label.
 */
function thirsty_molecule_seed_sections() {
	return array(
		'hero'        => __( 'Hero', 'thirsty-molecule' ),
		'trust'       => __( 'Trust', 'thirsty-molecule' ),
		'ticker'      => __( 'Ticker', 'thirsty-molecule' ),
		'range'       => __( 'Product Range', 'thirsty-molecule' ),
		'editorial'   => __( 'Editorial', 'thirsty-molecule' ),
		'positioning' => __( 'Positioning', 'thirsty-molecule' ),
		'different'   => __( 'Footer CTA / Different', 'thirsty-molecule' ),
		'values'      => __( 'Values', 'thirsty-molecule' ),
		'story'       => __( 'Story', 'thirsty-molecule' ),
		'reviews'     => __( 'Reviews', 'thirsty-molecule' ),
		'signup'      => __( 'Newsletter', 'thirsty-molecule' ),
	);
}

/**
 * Render one section template part to a string.
 *
 * @param string $slug Section slug.
 * @return string
 */
function thirsty_molecule_render_section_html( $slug ) {
	ob_start();
	get_template_part( 'template-parts/section', $slug );
	$html = trim( (string) ob_get_clean() );

	if ( '' === $html ) {
		return '';
	}

	return '<div class="tm-elementor-section tm-elementor-section--' . esc_attr( $slug ) . '">' . "\n" . $html . "\n" . '</div>';
}

/**
 * Unique Elementor element id (7 hex chars).
 *
 * @return string
 */
function thirsty_molecule_elementor_id() {
	return substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 7 );
}

/**
 * Build the full _elementor_data structure for the landing page.
 *
 * @return array
 */
function thirsty_molecule_build_elementor_data() {
	$data = array();

	foreach ( thirsty_molecule_seed_sections() as $slug => $label ) {
		$html = thirsty_molecule_render_section_html( $slug );

		if ( '' === $html ) {
			continue;
		}

		$data[] = array(
			'id'       => thirsty_molecule_elementor_id(),
			'elType'   => 'section',
			'settings' => array(
				'layout'            => 'full_width',
				'gap'               => 'no',
				'content_width'     => 'full',
				'structure'         => '10',
				'_title'            => $label,
				'padding'           => array(
					'unit'     => 'px',
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'isLinked' => true,
				),
			),
			'elements' => array(
				array(
					'id'       => thirsty_molecule_elementor_id(),
					'elType'   => 'column',
					'settings' => array(
						'_column_size' => 100,
						'_inline_size' => null,
						'padding'      => array(
							'unit'     => 'px',
							'top'      => '0',
							'right'    => '0',
							'bottom'   => '0',
							'left'     => '0',
							'isLinked' => true,
						),
					),
					'elements' => array(
						array(
							'id'         => thirsty_molecule_elementor_id(),
							'elType'     => 'widget',
							'widgetType' => 'html',
							'settings'   => array(
								'html'   => $html,
								'_title' => $label,
							),
							'elements'   => array(),
						),
					),
					'isInner'  => false,
				),
			),
			'isInner'  => false,
		);
	}

	return $data;
}

/**
 * Create (or refresh) the Home page and mark it as built with Elementor.
 *
 * @param bool $force Rebuild content even if the page already exists.
 * @return int Page ID or 0.
 */
function thirsty_molecule_seed_home_page( $force = false ) {
	$page_id = (int) get_option( 'thirsty_molecule_home_page_id' );

	if ( $page_id && 'page' !== get_post_type( $page_id ) ) {
		$page_id = 0;
	}

	if ( ! $page_id ) {
		$existing = get_page_by_path( 'home' );

		if ( $existing instanceof WP_Post ) {
			$page_id = (int) $existing->ID;
		}
	}

	if ( ! $page_id ) {
		$page_id = wp_insert_post(
			array(
				'post_title'   => __( 'Home', 'thirsty-molecule' ),
				'post_name'    => 'home',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '',
			)
		);

		if ( is_wp_error( $page_id ) || ! $page_id ) {
			return 0;
		}

		$force = true;
	}

	update_option( 'thirsty_molecule_home_page_id', (int) $page_id );

	// Front page settings.
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', (int) $page_id );

	$has_data = get_post_meta( $page_id, '_elementor_data', true );

	if ( $force || empty( $has_data ) ) {
		$data = thirsty_molecule_build_elementor_data();

		if ( empty( $data ) ) {
			return (int) $page_id;
		}

		update_post_meta( $page_id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
		update_post_meta( $page_id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $page_id, '_elementor_template_type', 'wp-page' );
		update_post_meta( $page_id, '_elementor_version', '3.0.0' );
		update_post_meta( $page_id, '_wp_page_template', 'elementor_header_footer' );

		if ( class_exists( '\\Elementor\\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}
	}

	return (int) $page_id;
}

/**
 * Seed on theme activation.
 *
 * @return void
 */
function thirsty_molecule_after_switch_theme() {
	thirsty_molecule_seed_home_page( true );
	update_option( 'thirsty_molecule_seeded', '1' );
	update_option( 'thirsty_molecule_content_version', THIRSTY_MOLECULE_VERSION );
}
add_action( 'after_switch_theme', 'thirsty_molecule_after_switch_theme' );

/**
 * If Elementor is installed after the theme, make sure the page exists and is
 * flagged as an Elementor document.
 *
 * @return void
 */
function thirsty_molecule_maybe_seed_home_page() {
	if ( ! is_admin() || ! current_user_can( 'edit_pages' ) ) {
		return;
	}

	$page_id = (int) get_option( 'thirsty_molecule_home_page_id' );
	$stored  = (string) get_option( 'thirsty_molecule_content_version', '' );

	if ( $page_id && get_post_meta( $page_id, '_elementor_data', true ) && THIRSTY_MOLECULE_VERSION === $stored ) {
		return;
	}

	thirsty_molecule_seed_home_page( true );
	update_option( 'thirsty_molecule_content_version', THIRSTY_MOLECULE_VERSION );
}
add_action( 'admin_init', 'thirsty_molecule_maybe_seed_home_page', 20 );

/**
 * Admin notice pointing to Elementor when it is missing.
 *
 * @return void
 */
function thirsty_molecule_elementor_notice() {
	if ( thirsty_molecule_has_elementor() || ! current_user_can( 'install_plugins' ) ) {
		return;
	}

	echo '<div class="notice notice-info"><p>' .
		esc_html__( 'Thirsty Molecule: install and activate the free Elementor plugin, then open Pages → Home → Edit with Elementor. The full landing page is already built there.', 'thirsty-molecule' ) .
		'</p></div>';
}
add_action( 'admin_notices', 'thirsty_molecule_elementor_notice' );

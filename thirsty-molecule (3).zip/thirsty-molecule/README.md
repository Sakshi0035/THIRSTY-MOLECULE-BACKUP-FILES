# Thirsty Molecule — WordPress Theme

A classic (PHP) WordPress theme that recreates the Thirsty Molecule landing-page
prototype pixel-for-pixel, with every section editable from the WordPress
Customizer. No page builder, no build step, no external framework.

## Requirements

- WordPress 6.0+
- PHP 7.4+

## Installation

1. In WordPress admin go to **Appearance → Themes → Add New → Upload Theme**.
2. Choose `thirsty-molecule.zip` and click **Install Now**.
3. Click **Activate**.

The landing page renders automatically on your site's front page
(`front-page.php`). If your front page is set to show your latest posts, the
landing page still takes priority; set **Settings → Reading → A static page** if
you want a dedicated page instead.

## Editing content

Everything on the landing page is editable — no code needed.

**Appearance → Customize** contains one panel per section:

- **Site Identity** — logo (falls back to the two-line wordmark), site title
- **Header / CTA** — header button label and link
- **Hero Carousel** — 4 slides: eyebrow, heading, body, two buttons, image
- **Trust Strip** — 3 cards: icon, title, subtitle
- **Ticker** — the scrolling marquee phrases
- **Product Range** — 4 product cards: badge, name, description, two feature
  chips, price or "Coming soon", button label and link, image
- **Editorial Banner** — split image/text band
- **Brand Positioning** — kicker, headline, highlighted phrase, body
- **What Makes Us Different** — dark rounded block copy
- **Why Thirsty Molecule** — 3 numbered value cards
- **Brand Story** — founder copy plus the yellow H₂O card
- **Reviews** — 3 review cards
- **Signup** — heading, subheading, placeholder, button, form action URL
- **Footer** — tagline, 3 link columns, social links, copyright

### Menus

**Appearance → Menus** — two locations:

- `Primary` — the desktop/mobile header navigation
- `Footer` — optional extra footer links

If no menu is assigned, the header falls back to the prototype's default links.

### Widgets

**Appearance → Widgets** — a `Footer Widgets` area is available if you'd rather
manage footer content with blocks/widgets than Customizer fields.

## Blog and inner pages

Standard templates ship with the theme and inherit the same design language:

- `index.php`, `home.php` — blog listing
- `single.php` — single post
- `page.php` — static pages
- `archive.php`, `search.php`, `404.php` — archives, search, not found
- `comments.php` — comment list and form

## Images

Prototype images live in `assets/images/` and are used as the defaults for the
hero, product cards and editorial banner. Replace any of them from the
Customizer with your own uploads from the Media Library — the originals stay
untouched.

## WooCommerce

The theme declares WooCommerce support, so shop, product and cart pages render
with the theme's typography and colours. Product-card "Shop now" buttons in the
Customizer can point at any WooCommerce product URL.

## Structure

```
thirsty-molecule/
├── style.css              theme header + base styles
├── functions.php          setup, assets, theme supports
├── header.php / footer.php
├── front-page.php         landing page orchestration
├── index.php single.php page.php archive.php search.php 404.php comments.php
├── inc/
│   ├── customizer.php     all Customizer panels and controls
│   ├── theme-content.php  default copy and content helpers
│   └── template-tags.php  branding and pagination helpers
├── template-parts/        one file per landing-page section
└── assets/
    ├── css/main.css       full prototype stylesheet
    ├── js/theme.js        carousel, ticker, mobile menu
    └── images/            prototype imagery
```

## Notes

- The hero carousel auto-advances every 1.5s, pauses on hover/focus, and
  supports arrows, dots, keyboard and touch swipe.
- The heading typeface is Fredoka, loaded from Google Fonts with preconnect
  hints; body text uses a system font stack for speed.
- No jQuery dependency; `theme.js` is vanilla JavaScript loaded deferred.


## Elementor support (free version)

The theme is Elementor-ready out of the box:

- **Full width page template** — when editing a page choose *Page Attributes → Template → Full Width (Elementor / Page Builder)*, or use Elementor's own *Elementor Full Width* / *Elementor Canvas* templates.
- **Thirsty Molecule widgets** — every landing-page section (Hero Carousel, Trust Strip, Ticker, Product Range, Editorial, Positioning, What Makes Us Different, Values, Brand Story, Reviews, Signup) appears in the Elementor panel under the **Thirsty Molecule** category. Drag them onto any page and reorder freely. Their copy/images stay editable in *Appearance → Customize*.
- **Brand colours & fonts** are pre-loaded as Elementor global colours (Pink, Aqua, Ink, Orange, Purple, Yellow) and global fonts (Fredoka headings, Montserrat body).
- **Header/footer** — the theme's own header and footer are used with free Elementor. If you install Elementor **Pro**, the theme registers the Theme Builder locations so Pro headers/footers/archives take over automatically.

### Recreating the homepage in Elementor
1. Pages → Add New → *Edit with Elementor*.
2. Set the template to Full Width / Canvas.
3. Drag the Thirsty Molecule section widgets in the order you like.
4. Settings → Reading → *A static page* → select it as the homepage.

## Elementor-ready homepage (v1.2.0)

On theme activation the theme automatically:

1. Creates a published page called **Home** and sets it as the static front page.
2. Builds it with Elementor, one **HTML widget per section** (Hero, Trust, Ticker,
   Product Range, Editorial, Positioning, Footer CTA, Values, Story, Reviews,
   Newsletter), each containing the original section HTML/CSS classes untouched.
3. Assigns the `Elementor Full Width` page template so the layout stays edge to edge.

Just install/activate the free Elementor plugin and go to **Pages → Home → Edit with Elementor** —
nothing to copy or paste. If Elementor is installed *after* the theme, the page is
seeded on the next admin page load.

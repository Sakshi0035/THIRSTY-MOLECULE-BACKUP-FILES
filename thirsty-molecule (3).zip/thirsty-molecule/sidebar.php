<?php
/**
 * Sidebar.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
<aside class="widget-area" aria-label="<?php esc_attr_e( 'Sidebar', 'thirsty-molecule' ); ?>">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>

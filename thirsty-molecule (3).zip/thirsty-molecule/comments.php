<?php
/**
 * Comments template.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="comments-area">
	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$tm_count = get_comments_number();
			printf(
				/* translators: %s: comment count. */
				esc_html( _n( '%s comment', '%s comments', $tm_count, 'thirsty-molecule' ) ),
				esc_html( number_format_i18n( $tm_count ) )
			);
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'      => 'ol',
					'short_ping' => true,
					'avatar_size' => 44,
				)
			);
			?>
		</ol>

		<?php
		the_comments_pagination(
			array(
				'class'     => 'tm-pagination',
				'prev_text' => esc_html__( 'Prev', 'thirsty-molecule' ),
				'next_text' => esc_html__( 'Next', 'thirsty-molecule' ),
			)
		);
		?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="entry-meta"><?php esc_html_e( 'Comments are closed.', 'thirsty-molecule' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'class_submit' => 'submit btn-pill',
			'title_reply'  => esc_html__( 'Leave a comment', 'thirsty-molecule' ),
		)
	);
	?>
</div>

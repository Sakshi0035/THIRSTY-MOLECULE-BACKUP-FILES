<?php
/**
 * Archive template.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<header class="page-header">
	<?php
	the_archive_title( '<h1 class="page-title">', '</h1>' );
	the_archive_description( '<div class="archive-description">', '</div>' );
	?>
</header>

<div class="site-main-inner<?php echo is_active_sidebar( 'sidebar-1' ) ? '' : ' no-sidebar'; ?>">
	<div>
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/content' );
			}
			thirsty_molecule_pagination();
		} else {
			get_template_part( 'template-parts/content', 'none' );
		}
		?>
	</div>
	<?php get_sidebar(); ?>
</div>

<?php
get_footer();

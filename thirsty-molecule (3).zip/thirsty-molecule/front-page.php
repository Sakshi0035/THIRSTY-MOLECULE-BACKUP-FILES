<?php
/**
 * Front page.
 *
 * When the static front page is built with Elementor (the theme seeds a "Home"
 * page full of HTML widgets on activation) we render that document instead of
 * the hard-coded template parts, so the sections are never duplicated.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

$tm_front_id = (int) get_option( 'page_on_front' );

if ( $tm_front_id && class_exists( '\\Elementor\\Plugin' ) ) {
	$tm_document = \Elementor\Plugin::$instance->documents->get( $tm_front_id );

	if ( $tm_document && $tm_document->is_built_with_elementor() ) {
		get_template_part( 'page' );
		return;
	}
}

get_header();

get_template_part( 'template-parts/section', 'hero' );
get_template_part( 'template-parts/section', 'trust' );
get_template_part( 'template-parts/section', 'ticker' );
get_template_part( 'template-parts/section', 'range' );
get_template_part( 'template-parts/section', 'editorial' );
get_template_part( 'template-parts/section', 'positioning' );
get_template_part( 'template-parts/section', 'different' );
get_template_part( 'template-parts/section', 'values' );
get_template_part( 'template-parts/section', 'story' );
get_template_part( 'template-parts/section', 'reviews' );
get_template_part( 'template-parts/section', 'signup' );

get_footer();

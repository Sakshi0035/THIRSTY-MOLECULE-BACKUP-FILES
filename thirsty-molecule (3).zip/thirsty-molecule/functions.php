<?php
/**
 * Thirsty Molecule theme functions and definitions.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

define( 'THIRSTY_MOLECULE_VERSION', '1.3.0' );

require_once get_template_directory() . '/inc/theme-content.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/template-tags.php';
require_once get_template_directory() . '/inc/elementor.php';
require_once get_template_directory() . '/inc/elementor-seed.php';

/**
 * Theme setup.
 *
 * @return void
 */
function thirsty_molecule_setup() {
	load_theme_textdomain( 'thirsty-molecule', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);

	add_theme_support(
		'custom-logo',
		array(
			'height'      => 90,
			'width'       => 300,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_theme_support(
		'custom-background',
		array(
			'default-color' => 'ffffff',
		)
	);

	add_theme_support(
		'custom-header',
		array(
			'default-text-color' => 'ffffff',
			'width'              => 1920,
			'height'             => 900,
			'flex-height'        => true,
			'flex-width'         => true,
			'header-text'        => false,
		)
	);

	register_nav_menus(
		array(
			'primary'     => __( 'Primary Menu', 'thirsty-molecule' ),
			'footer-shop' => __( 'Footer: Shop', 'thirsty-molecule' ),
			'footer-info' => __( 'Footer: Company', 'thirsty-molecule' ),
			'social'      => __( 'Footer: Follow', 'thirsty-molecule' ),
		)
	);

	add_editor_style( 'assets/css/main.css' );
}
add_action( 'after_setup_theme', 'thirsty_molecule_setup' );

/**
 * Content width.
 *
 * @return void
 */
function thirsty_molecule_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'thirsty_molecule_content_width', 1100 );
}
add_action( 'after_setup_theme', 'thirsty_molecule_content_width', 0 );

/**
 * Enqueue styles and scripts.
 *
 * @return void
 */
function thirsty_molecule_assets() {
	wp_enqueue_style(
		'thirsty-molecule-fonts',
		'https://fonts.googleapis.com/css2?family=Fredoka:wght@600;700&display=swap',
		array(),
		null // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
	);

	wp_enqueue_style(
		'thirsty-molecule-main',
		get_template_directory_uri() . '/assets/css/main.css',
		array( 'thirsty-molecule-fonts' ),
		THIRSTY_MOLECULE_VERSION
	);

	wp_enqueue_style(
		'thirsty-molecule-style',
		get_stylesheet_uri(),
		array( 'thirsty-molecule-main' ),
		THIRSTY_MOLECULE_VERSION
	);

	wp_enqueue_script(
		'thirsty-molecule-theme',
		get_template_directory_uri() . '/assets/js/theme.js',
		array(),
		THIRSTY_MOLECULE_VERSION,
		true
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'thirsty_molecule_assets' );

/**
 * Preconnect to the Google Fonts hosts used by the theme.
 *
 * @param array  $urls          URLs to print.
 * @param string $relation_type Relation type.
 * @return array
 */
function thirsty_molecule_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type && wp_style_is( 'thirsty-molecule-fonts', 'enqueued' ) ) {
		$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
		$urls[] = array( 'href' => 'https://fonts.googleapis.com' );
	}

	return $urls;
}
add_filter( 'wp_resource_hints', 'thirsty_molecule_resource_hints', 10, 2 );

/**
 * Register widget areas.
 *
 * @return void
 */
function thirsty_molecule_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Sidebar', 'thirsty-molecule' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Shown beside blog posts, archives and search results.', 'thirsty-molecule' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer Extra', 'thirsty-molecule' ),
			'id'            => 'footer-1',
			'description'   => __( 'Optional widgets shown above the footer columns.', 'thirsty-molecule' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'thirsty_molecule_widgets_init' );

/**
 * Add lazy/async decoding defaults to content images.
 *
 * @param array $attr Image attributes.
 * @return array
 */
function thirsty_molecule_image_attributes( $attr ) {
	if ( empty( $attr['loading'] ) ) {
		$attr['loading'] = 'lazy';
	}
	$attr['decoding'] = 'async';

	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'thirsty_molecule_image_attributes' );

/**
 * Body classes.
 *
 * @param array $classes Body classes.
 * @return array
 */
function thirsty_molecule_body_classes( $classes ) {
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-widgets';
	}
	if ( is_front_page() ) {
		$classes[] = 'tm-front';
	}

	return $classes;
}
add_filter( 'body_class', 'thirsty_molecule_body_classes' );

/**
 * Excerpt tail.
 *
 * @return string
 */
function thirsty_molecule_excerpt_more() {
	return '…';
}
add_filter( 'excerpt_more', 'thirsty_molecule_excerpt_more' );

/**
 * Default SEO meta description for the front page.
 *
 * @return void
 */
function thirsty_molecule_meta_description() {
	if ( ! is_front_page() && ! is_home() ) {
		return;
	}

	$description = get_theme_mod(
		'tm_meta_description',
		__( 'Thirsty Molecule makes hydration-first skincare: CetaGlow non-foaming niacinamide cleanser and HydraMatrix gel-cream moisturizer with Pentavitin, hyaluronic acid and ceramides.', 'thirsty-molecule' )
	);

	if ( ! $description ) {
		return;
	}

	echo '<meta name="description" content="' . esc_attr( $description ) . '" />' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( get_bloginfo( 'name', 'display' ) . ' | Hydration first. Everything good follows.' ) . '" />' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $description ) . '" />' . "\n";
	echo '<meta property="og:type" content="website" />' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
}
add_action( 'wp_head', 'thirsty_molecule_meta_description', 1 );
/**
 * ============================================================
 * THIRSTY MOLECULE — CUSTOM WOOCOMMERCE PRODUCT TEMPLATE
 * ============================================================
 */

/**
 * ============================================================
 * THIRSTY MOLECULE — CUSTOM SINGLE PRODUCT CONTENT
 * ============================================================
 */

function thirsty_molecule_custom_product_template() {

    if ( ! is_product() ) {
        return;
    }

    global $product;

    if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
        return;
    }

    /*
     * Remove WooCommerce default product output.
     */
    remove_action(
        'woocommerce_before_single_product_summary',
        'woocommerce_show_product_images',
        20
    );

    remove_action(
        'woocommerce_single_product_summary',
        'woocommerce_template_single_title',
        5
    );

    remove_action(
        'woocommerce_single_product_summary',
        'woocommerce_template_single_rating',
        10
    );

    remove_action(
        'woocommerce_single_product_summary',
        'woocommerce_template_single_price',
        10
    );

    remove_action(
        'woocommerce_single_product_summary',
        'woocommerce_template_single_excerpt',
        20
    );

    remove_action(
        'woocommerce_single_product_summary',
        'woocommerce_template_single_add_to_cart',
        30
    );

    remove_action(
        'woocommerce_single_product_summary',
        'woocommerce_template_single_meta',
        40
    );

    remove_action(
        'woocommerce_single_product_summary',
        'woocommerce_template_single_sharing',
        50
    );

    remove_action(
        'woocommerce_after_single_product_summary',
        'woocommerce_output_product_data_tabs',
        10
    );

    remove_action(
        'woocommerce_after_single_product_summary',
        'woocommerce_output_related_products',
        20
    );

    /*
     * Product data.
     */
    $product_id  = $product->get_id();
    $title       = $product->get_name();
    $price       = $product->get_price_html();
    $short_desc  = $product->get_short_description();
    $description = $product->get_description();
    $image_id    = $product->get_image_id();
    $gallery     = $product->get_gallery_image_ids();

    /*
     * Product H1.
     *
     * The supplied client H1 for HydraMatrix differs from
     * its WooCommerce product name.
     */
    $h1 = $title;

    if ( 'HydraMatrix Face Moisturizer' === $title ) {
        $h1 = 'HydraMatrix Gel-Cream Moisturizer';
    }

    /*
     * Product category.
     */
    $categories = wc_get_product_category_list( $product_id );

    ?>

    <div class="tm-product-page">

        <!-- ==================================================
             HERO
        =================================================== -->

        <section class="tm-product-hero">

            <div class="tm-product-hero-inner">

                <div class="tm-product-gallery">

                    <div class="tm-product-main-image">

                        <?php
                        if ( $image_id ) {

                            echo wp_get_attachment_image(
                                $image_id,
                                'large',
                                false,
                                array(
                                    'class' => 'tm-product-main-img',
                                )
                            );

                        } else {

                            echo wc_placeholder_img(
                                'large',
                                array(
                                    'class' => 'tm-product-main-img',
                                )
                            );

                        }
                        ?>

                    </div>


                    <?php if ( ! empty( $gallery ) ) : ?>

                        <div class="tm-product-gallery-thumbs">

                            <?php foreach ( $gallery as $gallery_id ) : ?>

                                <div class="tm-product-thumb">

                                    <?php
                                    echo wp_get_attachment_image(
                                        $gallery_id,
                                        'thumbnail',
                                        false,
                                        array(
                                            'class' => 'tm-product-thumb-img',
                                        )
                                    );
                                    ?>

                                </div>

                            <?php endforeach; ?>

                        </div>

                    <?php endif; ?>

                </div>


                <div class="tm-product-info">

                    <?php if ( $categories ) : ?>

                        <div class="tm-product-category">
                            <?php echo wp_kses_post( $categories ); ?>
                        </div>

                    <?php endif; ?>


                    <h1 class="tm-product-title">
                        <?php echo esc_html( $h1 ); ?>
                    </h1>


                    <?php if ( $short_desc ) : ?>

                        <div class="tm-product-short-description">

                            <?php
                            echo wp_kses_post( wpautop( $short_desc ) );
                            ?>

                        </div>

                    <?php endif; ?>


                    <div class="tm-product-price">

                        <?php echo wp_kses_post( $price ); ?>

                    </div>


                    <div class="tm-product-purchase">

                        <?php
                        woocommerce_template_single_add_to_cart();
                        ?>

                    </div>


                    <div class="tm-product-trust">

                        <span>Hydration-first skincare</span>
                        <span>Gentle formulations</span>
                        <span>Everyday skincare</span>

                    </div>

                </div>

            </div>

        </section>


        <!-- ==================================================
             FULL PRODUCT INFORMATION
        =================================================== -->

        <section class="tm-product-details">

            <div class="tm-product-details-inner">

                <div class="tm-product-details-heading">

                    <span class="tm-product-eyebrow">
                        THE FORMULA
                    </span>

                    <h2>
                        What's inside
                    </h2>

                </div>


                <div class="tm-product-description">

                    <?php
                    echo wp_kses_post( wpautop( $description ) );
                    ?>

                </div>

            </div>

        </section>


        <!-- ==================================================
             PRODUCT BENEFIT STRIP
        =================================================== -->

        <section class="tm-product-benefit-section">

            <div class="tm-product-benefit-inner">

                <div class="tm-product-benefit-heading">

                    <span class="tm-product-eyebrow">
                        AT A GLANCE
                    </span>

                    <h2>
                        Good skin starts with good basics.
                    </h2>

                </div>


                <div class="tm-product-benefit-cards">

                    <div class="tm-product-benefit-card">

                        <span class="tm-benefit-number">
                            01
                        </span>

                        <h3>
                            Hydration
                        </h3>

                        <p>
                            Thoughtfully selected ingredients designed to support comfortable, hydrated skin.
                        </p>

                    </div>


                    <div class="tm-product-benefit-card">

                        <span class="tm-benefit-number">
                            02
                        </span>

                        <h3>
                            Skin Barrier
                        </h3>

                        <p>
                            Formulated with ingredients selected to support the skin's natural moisture barrier.
                        </p>

                    </div>


                    <div class="tm-product-benefit-card">

                        <span class="tm-benefit-number">
                            03
                        </span>

                        <h3>
                            Everyday Care
                        </h3>

                        <p>
                            Designed to fit simply into an everyday skincare routine.
                        </p>

                    </div>

                </div>

            </div>

        </section>


        <!-- ==================================================
             FULL DETAILS
        =================================================== -->

        <section class="tm-product-full-details">

            <div class="tm-product-full-details-inner">

                <div class="tm-detail-column">

                    <span class="tm-product-eyebrow">
                        PRODUCT INFORMATION
                    </span>

                    <h2>
                        Details
                    </h2>

                </div>


                <div class="tm-detail-content">

                    <?php
                    echo wp_kses_post( wpautop( $description ) );
                    ?>

                </div>

            </div>

        </section>


        <!-- ==================================================
             RELATED PRODUCTS
        =================================================== -->

        <section class="tm-product-related">

            <div class="tm-product-related-inner">

                <span class="tm-product-eyebrow">
                    KEEP EXPLORING
                </span>

                <h2>
                    Build your routine.
                </h2>

                <?php
                woocommerce_output_related_products();
                ?>

            </div>

        </section>

    </div>

    <?php
}

add_action(
    'woocommerce_before_single_product',
    'thirsty_molecule_custom_product_template',
    5
);
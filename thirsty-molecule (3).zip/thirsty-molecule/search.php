<?php
/**
 * Search results.
 *
 * @package Thirsty_Molecule
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<header class="page-header">
	<h1 class="page-title">
		<?php
		printf(
			/* translators: %s: search query. */
			esc_html__( 'Results for “%s”', 'thirsty-molecule' ),
			esc_html( get_search_query() )
		);
		?>
	</h1>
	<div class="archive-description"><?php get_search_form(); ?></div>
</header>

<div class="site-main-inner<?php echo is_active_sidebar( 'sidebar-1' ) ? '' : ' no-sidebar'; ?>">
	<div>
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/content' );
			}
			thirsty_molecule_pagination();
		} else {
			get_template_part( 'template-parts/content', 'none' );
		}
		?>
	</div>
	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
